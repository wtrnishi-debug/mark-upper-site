const SUPABASE_URL = 'https://qchlbplywjpnxddytqpr.supabase.co';
const SUPABASE_KEY = 'sb_publishable_6FONET_27FmnG0_kJE95sg_QI4gxAQG';

const SB_HEADERS = {
  'apikey': SUPABASE_KEY,
  'Authorization': `Bearer ${SUPABASE_KEY}`,
  'Content-Type': 'application/json'
};

async function sb_query(path, method = 'GET', body = null) {
  const options = {
    method,
    headers: {
      ...SB_HEADERS,
      ...(method === 'POST' ? { 'Prefer': 'return=representation' } : {})
    }
  };
  if (body) options.body = JSON.stringify(body);

  const res = await fetch(`${SUPABASE_URL}/rest/v1${path}`, options);
  if (res.status === 204) return null;
  const data = await res.json();
  if (!res.ok) throw new Error(JSON.stringify(data));
  return data;
}

async function sb_getMembers() {
  return sb_query('/members?select=name&order=name.asc');
}

async function sb_addMember(name) {
  try {
    await sb_query('/members', 'POST', { name });
  } catch (e) {
    // 重複エラーは無視
  }
}

async function sb_getComments(siteUrl, device) {
  const url = encodeURIComponent(siteUrl);
  const dev = encodeURIComponent(device);
  return sb_query(
    `/comments?site_url=eq.${url}&device=eq.${dev}&parent_id=is.null&select=*&order=created_at.asc`
  );
}

async function sb_getReplies(parentId) {
  return sb_query(`/comments?parent_id=eq.${parentId}&select=*&order=created_at.asc`);
}

async function sb_addComment(data) {
  return sb_query('/comments', 'POST', data);
}

async function sb_deleteComment(id) {
  await fetch(`${SUPABASE_URL}/rest/v1/comments?id=eq.${id}`, {
    method: 'DELETE',
    headers: SB_HEADERS
  });
}

async function sb_updateStatus(id, status) {
  await fetch(`${SUPABASE_URL}/rest/v1/comments?id=eq.${id}`, {
    method: 'PATCH',
    headers: SB_HEADERS,
    body: JSON.stringify({ status })
  });
}

async function sb_updateImagePaths(id, paths) {
  await fetch(`${SUPABASE_URL}/rest/v1/comments?id=eq.${id}`, {
    method: 'PATCH',
    headers: SB_HEADERS,
    body: JSON.stringify({ image_paths: paths })
  });
}

async function sb_uploadImage(file, commentId) {
  const ext = file.name.split('.').pop() || 'png';
  const path = `${commentId}/${Date.now()}.${ext}`;

  const res = await fetch(`${SUPABASE_URL}/storage/v1/object/comment-images/${path}`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': file.type
    },
    body: file
  });

  if (!res.ok) throw new Error('画像のアップロードに失敗しました');
  return `${SUPABASE_URL}/storage/v1/object/public/comment-images/${path}`;
}
