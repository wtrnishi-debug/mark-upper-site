const DASHBOARD_URL = 'https://wtrnishi-debug.github.io/mark-upper-site/app/';

let isActive = false;
let currentDevice = 'pc';
let currentSessionId = null;

async function checkUpdateBanner() {
  const { mu_update_version, mu_update_notes, mu_update_download } =
    await chrome.storage.local.get(['mu_update_version', 'mu_update_notes', 'mu_update_download']);
  if (!mu_update_version) return;
  const banner = document.getElementById('update-banner');
  document.getElementById('update-text').textContent = `🆙 v${mu_update_version} が出ています — ${mu_update_notes || ''}`;
  document.getElementById('update-link').href = mu_update_download || '#';
  banner.style.display = 'flex';
  document.getElementById('update-dismiss').addEventListener('click', async () => {
    banner.style.display = 'none';
    await chrome.storage.local.set({ mu_dismissed_version: mu_update_version });
    chrome.action.setBadgeText({ text: '' });
  });
}

async function getTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function msgContent(msg) {
  const tab = await getTab();
  return chrome.tabs.sendMessage(tab.id, msg);
}

document.addEventListener('DOMContentLoaded', async () => {
  checkUpdateBanner();
  const stored = await chrome.storage.local.get(['mu_username', 'mu_device']);
  currentDevice = stored.mu_device || 'pc';

  if (!stored.mu_username) {
    show('name-screen');
  } else {
    showMain(stored.mu_username);
    try {
      const state = await msgContent({ type: 'GET_STATE' });
      if (state) {
        isActive = state.active;
        currentDevice = state.device || currentDevice;
        currentSessionId = state.sessionId || null;
        document.getElementById('count').textContent = state.commentCount ?? 0;
        updateToggleBtn();
        updateDeviceBtns();
        updateShareBtn();
      }
    } catch (e) {}
  }

  document.getElementById('name-save').addEventListener('click', async () => {
    const name = document.getElementById('name-input').value.trim();
    if (!name) return;
    await chrome.storage.local.set({ mu_username: name });
    try { await msgContent({ type: 'SET_USERNAME', name }); } catch (e) {}
    showMain(name);
  });

  document.getElementById('name-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.isComposing) document.getElementById('name-save').click();
  });

  document.getElementById('name-change').addEventListener('click', () => {
    show('name-screen');
    document.getElementById('name-input').value = '';
  });

  document.getElementById('toggle-btn').addEventListener('click', async () => {
    try {
      const res = await msgContent({ type: 'TOGGLE_ACTIVE' });
      isActive = res.active;
      currentSessionId = res.sessionId || currentSessionId;
    } catch (e) {
      const tab = await getTab();
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['supabase.js', 'content.js'] });
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content.css'] });
      await new Promise(r => setTimeout(r, 300));
      try {
        const res = await msgContent({ type: 'TOGGLE_ACTIVE' });
        isActive = res.active;
        currentSessionId = res.sessionId || currentSessionId;
      } catch (e2) {}
    }
    updateToggleBtn();
    updateShareBtn();
  });

  document.getElementById('pc-btn').addEventListener('click', () => switchDevice('pc'));
  document.getElementById('mobile-btn').addEventListener('click', () => switchDevice('mobile'));

  document.getElementById('share-btn').addEventListener('click', async () => {
    if (!currentSessionId) {
      // アクティブでなければ先にONにするよう促す
      const btn = document.getElementById('share-btn');
      btn.textContent = '⚠ 先にコメントモードをONにしてください';
      setTimeout(() => { btn.textContent = '🔗 URLをコピーして共有'; }, 2500);
      return;
    }
    const url = `${DASHBOARD_URL}?s=${currentSessionId}`;
    try {
      await navigator.clipboard.writeText(url);
      const btn = document.getElementById('share-btn');
      btn.textContent = '✅ コピーしました！';
      setTimeout(() => { btn.textContent = '🔗 URLをコピーして共有'; }, 2000);
    } catch (_) {
      // clipboardが使えない場合はダッシュボードを開く
      chrome.tabs.create({ url: `${DASHBOARD_URL}?s=${currentSessionId}` });
    }
  });
});

async function switchDevice(device) {
  if (currentDevice === device) return;
  currentDevice = device;
  chrome.storage.local.set({ mu_device: device });
  updateDeviceBtns();
  try { await msgContent({ type: 'SET_DEVICE', device }); } catch (e) {}
  chrome.runtime.sendMessage({ type: 'RESIZE_WINDOW', mode: device });
}

function showMain(name) {
  show('main-screen');
  document.getElementById('username-disp').textContent = '👤 ' + name;
  updateToggleBtn();
  updateDeviceBtns();
  updateShareBtn();
}

function show(id) {
  ['name-screen', 'main-screen'].forEach(s => {
    document.getElementById(s).style.display = s === id ? 'flex' : 'none';
  });
}

function updateToggleBtn() {
  const btn = document.getElementById('toggle-btn');
  btn.textContent = isActive ? 'コメントモードをOFFにする' : 'コメントモードをONにする';
  btn.className = 'btn btn-primary btn-full' + (isActive ? ' active' : '');
}

function updateDeviceBtns() {
  document.getElementById('pc-btn').className = 'dev-btn' + (currentDevice === 'pc' ? ' active' : '');
  document.getElementById('mobile-btn').className = 'dev-btn' + (currentDevice === 'mobile' ? ' active' : '');
}

function updateShareBtn() {
  const btn = document.getElementById('share-btn');
  if (!btn) return;
  btn.style.opacity = currentSessionId ? '1' : '0.5';
}
