const SUPABASE_URL = 'https://hiccejzetnmmvyopyykw.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpY2NlanpldG5tbXZ5b3B5eWt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg4MjkwMTYsImV4cCI6MjA5NDQwNTAxNn0.Oo_KrFflZhhWOlaN_hT9XZpBjhDFAgccK82CyrgC3qU';

const SB_HEADERS = {
  'apikey': SUPABASE_KEY,
  'Authorization': `Bearer ${SUPABASE_KEY}`,
  'Content-Type': 'application/json'
};

// CSP回避のためbackground service worker経由でfetch
function sb_fetch(url, options = {}) {
  return new Promise((resolve) => {
    if (!chrome.runtime?.id) { resolve(null); return; }
    try {
      chrome.runtime.sendMessage(
        { type: 'SUPABASE_FETCH', url, method: options.method || 'GET', headers: options.headers, body: options.body, isBase64: options.isBase64 },
        (res) => resolve(chrome.runtime.lastError ? null : (res || null))
      );
    } catch (_) { resolve(null); }
  });
}

async function sb_query(path, method = 'GET', body = null) {
  try {
    const headers = {
      ...SB_HEADERS,
      ...(method === 'POST' ? { 'Prefer': 'return=representation' } : {})
    };
    const res = await sb_fetch(`${SUPABASE_URL}/rest/v1${path}`, {
      method, headers,
      body: body ? JSON.stringify(body) : undefined
    });
    if (!res) return null;
    if (res.status === 204) return null;
    if (!res.ok) throw new Error(JSON.stringify(res.data));
    return res.data;
  } catch (e) {
    console.warn('[Mark Upper]', e.message);
    return null;
  }
}

// ── セッション ─────────────────────────────────────────────
async function sb_getOrCreateSession(domain) {
  const existing = await sb_query(
    `/mu_sessions?domain=eq.${encodeURIComponent(domain)}&order=created_at.desc&limit=1`
  );
  if (existing?.length) return existing[0];
  const created = await sb_query('/mu_sessions', 'POST', { domain });
  return created?.[0] || null;
}

async function sb_getSessionById(id) {
  const data = await sb_query(`/mu_sessions?id=eq.${encodeURIComponent(id)}`);
  return data?.[0] || null;
}

// ── メンバー（@メンション補完用）──────────────────────────
async function sb_getMembers() {
  return sb_query('/mu_members?select=name&order=name.asc');
}

async function sb_addMember(name) {
  // 同名が既にあれば無視（unique制約違反 23505 のエラーログを避けるため ignore-duplicates）。
  // sb_query ではなく sb_fetch を直接使い、重複時もエラーを出さない。
  try {
    await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_members?on_conflict=name`, {
      method: 'POST',
      headers: { ...SB_HEADERS, 'Prefer': 'resolution=ignore-duplicates,return=minimal' },
      body: JSON.stringify({ name })
    });
  } catch (_) {}
}

// ── コメント ───────────────────────────────────────────────
async function sb_getAllSessionComments(sessionId) {
  const sid = encodeURIComponent(sessionId);
  return sb_query(
    `/mu_comments?session_id=eq.${sid}&parent_id=is.null&select=*&order=page_url.asc,created_at.asc`
  );
}

async function sb_getComments(sessionId, pageUrl, breakpoint) {
  const sid = encodeURIComponent(sessionId);
  const url = encodeURIComponent(pageUrl);
  const bp  = encodeURIComponent(breakpoint);
  return sb_query(
    `/mu_comments?session_id=eq.${sid}&page_url=eq.${url}&breakpoint=eq.${bp}&parent_id=is.null&select=*&order=created_at.asc`
  );
}

async function sb_getReplies(parentId) {
  return sb_query(`/mu_comments?parent_id=eq.${encodeURIComponent(parentId)}&select=*&order=created_at.asc`);
}

async function sb_addComment(data) {
  return sb_query('/mu_comments', 'POST', data);
}

async function sb_deleteComment(id) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_deleteSessionComments(sessionId) {
  const sid = encodeURIComponent(sessionId);
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?session_id=eq.${sid}`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_deletePageComments(sessionId, pageUrl) {
  const sid = encodeURIComponent(sessionId);
  const url = encodeURIComponent(pageUrl);
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?session_id=eq.${sid}&page_url=eq.${url}`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_deleteAllComments(sessionId, pageUrl) {
  const sid = encodeURIComponent(sessionId);
  const url = encodeURIComponent(pageUrl);
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?session_id=eq.${sid}&page_url=eq.${url}&parent_id=is.null`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_updateStatus(id, status) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH', headers: SB_HEADERS, body: JSON.stringify({ status })
  });
}

async function sb_updatePosition(id, pos) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH', headers: SB_HEADERS, body: JSON.stringify(pos)
  });
}

async function sb_updateImagePaths(id, paths) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH', headers: SB_HEADERS, body: JSON.stringify({ image_paths: paths })
  });
}

async function sb_getMySites(userName) {
  if (!userName) return [];
  const comments = await sb_query(
    `/mu_comments?author=eq.${encodeURIComponent(userName)}&parent_id=is.null&select=session_id,status`
  );
  if (!comments?.length) return [];
  const counts = {};
  comments.forEach(c => {
    if (!counts[c.session_id]) counts[c.session_id] = { open: 0, fixed: 0, verified: 0, rejected: 0, total: 0 };
    counts[c.session_id][c.status] = (counts[c.session_id][c.status] || 0) + 1;
    counts[c.session_id].total++;
  });
  const ids = Object.keys(counts);
  const sessions = await sb_query(`/mu_sessions?id=in.(${ids.join(',')})&select=id,domain`);
  return (sessions || [])
    .map(s => ({ domain: s.domain, id: s.id, status: counts[s.id] || { open: 0, fixed: 0, verified: 0, rejected: 0, total: 0 } }))
    .sort((a, b) => b.status.total - a.status.total);
}

// 添付対応形式と拡張子→MIME。HEIC/AVIF等はブラウザが file.type を空で返すことがあるため
// 拡張子から MIME を補い、Content-Type 化けによる「タップしても表示されない」を防ぐ。
const MU_IMG_EXT_MIME = {
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
  webp: 'image/webp', avif: 'image/avif', heic: 'image/heic', mp4: 'video/mp4'
};
function muExtOf(name) { return (name.split('.').pop() || '').toLowerCase(); }
function muIsSupportedFile(name) { return Object.prototype.hasOwnProperty.call(MU_IMG_EXT_MIME, muExtOf(name)); }
function muMimeFor(file) { return file.type || MU_IMG_EXT_MIME[muExtOf(file.name)] || 'application/octet-stream'; }

async function sb_uploadImage(file, commentId) {
  const ext  = muExtOf(file.name) || 'png';
  const path = `${commentId}/${Date.now()}.${ext}`;
  // ArrayBuffer は sendMessage で消失するケースがあるため Base64 文字列で渡す
  const base64 = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
  const res = await sb_fetch(`${SUPABASE_URL}/storage/v1/object/comment-images/${path}`, {
    method: 'POST',
    headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`, 'Content-Type': muMimeFor(file) },
    body: base64,
    isBase64: true
  });
  if (!res || !res.ok) {
    const detail = res?.data?.message || res?.data?.error || JSON.stringify(res?.data) || '';
    throw new Error(`${res?.status}: ${detail}`);
  }
  return `${SUPABASE_URL}/storage/v1/object/public/comment-images/${path}`;
}
