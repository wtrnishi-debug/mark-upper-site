// サイトURLが確定したらここを書き換える
const UPDATE_CHECK_URL = 'https://wtrnishi-debug.github.io/mark-upper-site/version.json';
const CURRENT_VERSION  = '2.20.14';

// デバイスごとの起動時ウィンドウサイズ
const MU_FIXED_WIDTH = { pc: { w: 1366, h: 768 }, mobile: { w: 375, h: 667 } };

// アイコンクリックでコメントモードをON/OFF
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    const res = await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_ACTIVE' });
    chrome.action.setBadgeText({ text: res?.active ? 'ON' : '', tabId: tab.id });
    chrome.action.setBadgeBackgroundColor({ color: '#7c3aed', tabId: tab.id });
  } catch (_) {}
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SET_BADGE') {
    const tabId = sender.tab?.id;
    if (tabId) {
      chrome.action.setBadgeText({ text: msg.text || '', tabId });
      if (msg.text) chrome.action.setBadgeBackgroundColor({ color: msg.color || '#7c3aed', tabId });
    }
    return;
  }
  if (msg.type === 'RESIZE_WINDOW') {
    let targetWidth, targetHeight;
    if (msg.width) {
      // ピンのビューポートサイズに合わせてリサイズ
      targetWidth  = msg.width;
      targetHeight = msg.height || null;
    } else {
      // PC/Mobile のプリセットサイズ
      const mode = msg.mode === 'mobile' ? 'mobile' : 'pc';
      targetWidth  = MU_FIXED_WIDTH[mode].w;
      targetHeight = MU_FIXED_WIDTH[mode].h;
    }
    chrome.windows.getCurrent((win) => {
      const props = { width: targetWidth, state: 'normal', left: 0, top: 0 };
      if (targetHeight) props.height = targetHeight;
      chrome.windows.update(win.id, props, () => {
        if (sendResponse) sendResponse({ ok: true, width: targetWidth });
      });
    });
    return true; // 非同期レスポンス
  }
});

// 画像をdataURLとして取得（CSP回避）
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'FETCH_IMAGE') return;
  fetch(msg.url)
    .then(res => res.blob())
    .then(blob => {
      const reader = new FileReader();
      reader.onload  = () => sendResponse({ ok: true, dataUrl: reader.result });
      reader.onerror = () => sendResponse({ ok: false });
      reader.readAsDataURL(blob);
    })
    .catch(() => sendResponse({ ok: false }));
  return true;
});

// Supabase 定数（スクリーンショットの直接アップロード用）
const MU_SB_URL = 'https://hiccejzetnmmvyopyykw.supabase.co';
const MU_SB_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpY2NlanpldG5tbXZ5b3B5eWt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg4MjkwMTYsImV4cCI6MjA5NDQwNTAxNn0.Oo_KrFflZhhWOlaN_hT9XZpBjhDFAgccK82CyrgC3qU';
const MU_SCREENSHOTS = new Map();

// スクリーンショット: キャプチャ→OffscreenCanvas圧縮→一時保存→プレビュー返却
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'CAPTURE_SCREENSHOT') return;
  chrome.tabs.captureVisibleTab(null, { format: 'jpeg', quality: 80 }, async (dataUrl) => {
    if (chrome.runtime.lastError || !dataUrl) {
      sendResponse({ ok: false, error: chrome.runtime.lastError?.message || 'キャプチャ失敗' });
      return;
    }
    try {
      const res    = await fetch(dataUrl);
      const blob   = await res.blob();
      const bitmap = await createImageBitmap(blob);
      const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
      canvas.getContext('2d').drawImage(bitmap, 0, 0);
      let finalBlob = blob;
      const MAX = 300 * 1024;
      for (let q = 0.6; q >= 0.05; q = Math.round((q - 0.1) * 10) / 10) {
        const b = await canvas.convertToBlob({ type: 'image/jpeg', quality: q });
        finalBlob = b;
        if (b.size <= MAX) break;
      }
      const tempId = crypto.randomUUID();
      MU_SCREENSHOTS.set(tempId, finalBlob);
      const reader = new FileReader();
      reader.onload  = () => sendResponse({ ok: true, tempId, preview: reader.result });
      reader.onerror = () => sendResponse({ ok: false, error: 'preview失敗' });
      reader.readAsDataURL(finalBlob);
    } catch (e) {
      sendResponse({ ok: false, error: e.message });
    }
  });
  return true;
});

// スクリーンショット: 一時保存済みblobをSupabaseへ直接アップロード
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'UPLOAD_SCREENSHOT') return;
  const blob = MU_SCREENSHOTS.get(msg.tempId);
  if (!blob) { sendResponse({ ok: false, error: 'スクリーンショットが見つかりません（再撮影してください）' }); return; }
  const path = `${msg.commentId}/${Date.now()}.jpg`;
  blob.arrayBuffer()
    .then(buf => fetch(`${MU_SB_URL}/storage/v1/object/comment-images/${path}`, {
      method: 'POST',
      headers: { 'apikey': MU_SB_KEY, 'Authorization': `Bearer ${MU_SB_KEY}`, 'Content-Type': 'image/jpeg' },
      body: buf
    }))
    .then(async r => {
      if (!r.ok) {
        const d = await r.json().catch(() => ({}));
        sendResponse({ ok: false, error: `${r.status}: ${d.message || ''}` });
        return;
      }
      MU_SCREENSHOTS.delete(msg.tempId);
      sendResponse({ ok: true, url: `${MU_SB_URL}/storage/v1/object/public/comment-images/${path}` });
    })
    .catch(e => sendResponse({ ok: false, error: e.message }));
  return true;
});

// Supabase の fetch をここで代理実行（Content Script はページの CSP に縛られるため）
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== 'SUPABASE_FETCH') return;
  const opts = { method: msg.method || 'GET', headers: msg.headers };
  if (msg.body !== undefined) {
    if (msg.isBase64) {
      const binary = atob(msg.body);
      const bytes  = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      opts.body = bytes.buffer;
    } else {
      opts.body = msg.body;
    }
  }
  fetch(msg.url, opts)
    .then(async res => {
      if (res.status === 204) { sendResponse({ ok: true, status: 204, data: null }); return; }
      try {
        const data = await res.json();
        sendResponse({ ok: res.ok, status: res.status, data });
      } catch (_) {
        sendResponse({ ok: res.ok, status: res.status, data: null });
      }
    })
    .catch(err => sendResponse({ ok: false, error: err.message }));
  return true; // 非同期レスポンスのためチャネルを保持
});

// 起動時とアラーム時にアップデートをチェック
chrome.runtime.onInstalled.addListener(checkForUpdates);
chrome.runtime.onStartup.addListener(checkForUpdates);

chrome.alarms.create('updateCheck', { periodInMinutes: 360 }); // 6時間ごと
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'updateCheck') checkForUpdates();
});

function isNewerVersion(remote, current) {
  const r = remote.split('.').map(Number);
  const c = current.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((r[i] || 0) > (c[i] || 0)) return true;
    if ((r[i] || 0) < (c[i] || 0)) return false;
  }
  return false;
}

async function checkForUpdates() {
  if (UPDATE_CHECK_URL.includes('YOUR_SITE')) return; // URL未設定時はスキップ
  try {
    const res  = await fetch(UPDATE_CHECK_URL + '?t=' + Date.now());
    const data = await res.json();
    const { mu_dismissed_version } = await chrome.storage.local.get('mu_dismissed_version');

    if (isNewerVersion(data.version, CURRENT_VERSION) && data.version !== mu_dismissed_version) {
      chrome.action.setBadgeText({ text: '↑' });
      chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
      chrome.storage.local.set({
        mu_update_version:  data.version,
        mu_update_notes:    data.notes,
        mu_update_download: data.download
      });
    } else {
      chrome.action.setBadgeText({ text: '' });
      chrome.storage.local.remove(['mu_update_version', 'mu_update_notes', 'mu_update_download']);
    }
  } catch (_) {}
}
