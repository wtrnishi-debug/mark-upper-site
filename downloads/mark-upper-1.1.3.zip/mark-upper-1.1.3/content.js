const MU = {
  active: false,
  device: 'pc',
  userName: '',
  comments: [],
  pinElements: {},
  selectedId: null
};

let MU_HOVER_TIMER = null;

(async function init() {
  const stored = await chrome.storage.local.get(['mu_username', 'mu_device']);
  if (stored.mu_username) MU.userName = stored.mu_username;
  if (stored.mu_device) MU.device = stored.mu_device;
  chrome.runtime.onMessage.addListener(handleMessage);
})();

function handleMessage(msg, sender, sendResponse) {
  if (msg.type === 'GET_STATE') {
    sendResponse({ active: MU.active, device: MU.device, userName: MU.userName, commentCount: MU.comments.length });
    return true;
  }
  if (msg.type === 'TOGGLE_ACTIVE') {
    MU.active ? deactivate() : activate();
    sendResponse({ active: MU.active });
    return true;
  }
  if (msg.type === 'SET_USERNAME') {
    MU.userName = msg.name;
    chrome.storage.local.set({ mu_username: msg.name });
    sb_addMember(msg.name);
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'SET_DEVICE') {
    setDevice(msg.device);
    sendResponse({ ok: true });
    return true;
  }
}

let MU_ORIG_MARGIN_TOP = null;
let MU_POLL_TIMER = null;
let MU_READ_IDS = new Set();
let MU_OBJECT_URLS = [];
const MU_CACHE = { pc: null, mobile: null };

function readKey() { return 'mu_read_' + MU.userName; }

async function activate() {
  if (!MU.userName) return;
  MU.active = true;
  MU_ORIG_MARGIN_TOP = document.body.style.marginTop || '';
  const current = parseInt(getComputedStyle(document.body).marginTop) || 0;
  document.body.style.marginTop = (current + 48) + 'px';
  buildUI();
  const readData = await chrome.storage.local.get(readKey());
  MU_READ_IDS = new Set(readData[readKey()] || []);
  await loadComments();
  startPolling();
}

function deactivate() {
  MU.active = false;
  stopPolling();
  document.body.style.marginTop = MU_ORIG_MARGIN_TOP ?? '';
  window.removeEventListener('resize', syncOverlaySize);
  ['mu-toolbar', 'mu-overlay'].forEach(id => document.getElementById(id)?.remove());
}

function startPolling() {
  stopPolling();
  MU_POLL_TIMER = setInterval(pollComments, 20000);
}

function stopPolling() {
  clearInterval(MU_POLL_TIMER);
  MU_POLL_TIMER = null;
}

async function pollComments() {
  if (!MU.active) return;
  try {
    const fresh = await sb_getComments(window.location.href, MU.device);
    if (!fresh) return;
    const currentIds = new Set(MU.comments.map(c => c.id));
    const newCount = fresh.filter(c => !currentIds.has(c.id)).length;
    if (newCount > 0) showNotify(newCount, fresh);
  } catch (_) {}
}

function showNotify(count, fresh) {
  const existing = document.getElementById('mu-notify-btn');
  if (existing) { existing.dataset.fresh = JSON.stringify(fresh); existing.textContent = `🔔 ${count}件の新着`; return; }
  const btn = document.createElement('button');
  btn.id = 'mu-notify-btn';
  btn.className = 'mu-btn mu-notify-btn';
  btn.textContent = `🔔 ${count}件の新着`;
  btn.dataset.fresh = JSON.stringify(fresh);
  btn.addEventListener('click', async () => {
    const data = JSON.parse(btn.dataset.fresh);
    btn.remove();
    Object.values(MU.pinElements).forEach(el => el.remove());
    MU.pinElements = {};
    MU.comments = data;
    syncOverlaySize();
    MU.comments.forEach(addPin);
    updateBadge();
    closePopover();
  });
  document.getElementById('mu-toolbar')?.querySelector('.mu-right')?.prepend(btn);
}

// オーバーレイのサイズをページ全体に合わせる
function syncOverlaySize() {
  const overlay = document.getElementById('mu-overlay');
  if (!overlay) return;
  const w = Math.max(document.documentElement.scrollWidth, document.body.scrollWidth);
  const h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
  overlay.style.width  = w + 'px';
  overlay.style.height = h + 'px';
}

function overlayDims() {
  const overlay = document.getElementById('mu-overlay');
  return {
    w: parseFloat(overlay?.style.width)  || document.documentElement.scrollWidth,
    h: parseFloat(overlay?.style.height) || document.documentElement.scrollHeight
  };
}

function buildUI() {
  ['mu-toolbar', 'mu-overlay'].forEach(id => document.getElementById(id)?.remove());

  const toolbar = document.createElement('div');
  toolbar.id = 'mu-toolbar';
  toolbar.innerHTML = `
    <div class="mu-left">
      <span class="mu-logo">Mark Upper</span>
      <span class="mu-user">👤 ${escHtml(MU.userName)}</span>
    </div>
    <div class="mu-center">
      <div class="mu-seg">
        <button class="mu-seg-btn${MU.device === 'pc' ? ' mu-seg-on' : ''}" id="mu-dev-pc">💻 PC</button>
        <button class="mu-seg-btn${MU.device === 'mobile' ? ' mu-seg-on' : ''}" id="mu-dev-mobile">📱 Mobile</button>
      </div>
    </div>
    <div class="mu-right">
      <div class="mu-counts" id="mu-counts"></div>
      <button class="mu-btn mu-off-btn" id="mu-off-btn">✕ 終了</button>
    </div>`;
  document.body.appendChild(toolbar);

  const overlay = document.createElement('div');
  overlay.id = 'mu-overlay';
  document.body.appendChild(overlay);

  // ページ全体を覆うサイズに設定
  syncOverlaySize();
  window.addEventListener('resize', syncOverlaySize);
  overlay.classList.add('mu-cross');

  document.getElementById('mu-off-btn').addEventListener('click', deactivate);
  document.getElementById('mu-dev-pc').addEventListener('click', () => {
    setDevice('pc');
    chrome.runtime.sendMessage({ type: 'RESIZE_WINDOW', mode: 'pc' });
  });
  document.getElementById('mu-dev-mobile').addEventListener('click', () => {
    setDevice('mobile');
    chrome.runtime.sendMessage({ type: 'RESIZE_WINDOW', mode: 'mobile' });
  });
  overlay.addEventListener('click', onOverlayClick);
}

function onOverlayClick(e) {
  if (e.target !== document.getElementById('mu-overlay')) return;
  if (document.getElementById('mu-popover')) { closePopover(); return; }
  const { w, h } = overlayDims();
  const pageX = e.clientX + window.pageXOffset;
  const pageY = e.clientY + window.pageYOffset;
  const xPct = (pageX / w) * 100;
  const yPct = (pageY / h) * 100;
  openCommentForm(xPct, yPct, pageX, pageY);
}

// ポップオーバーをページ座標に表示
function showPopover(pageX, pageY, html) {
  document.getElementById('mu-popover')?.remove();
  const overlay = document.getElementById('mu-overlay');

  const pop = document.createElement('div');
  pop.id = 'mu-popover';
  pop.className = 'mu-pop';
  pop.innerHTML = html;
  overlay.appendChild(pop);
  overlay.classList.add('mu-pop-open');

  const OFFSET = 16;
  pop.style.left = (pageX + OFFSET) + 'px';
  pop.style.top  = (pageY + OFFSET) + 'px';

  // 画面端からはみ出す場合に反転
  requestAnimationFrame(() => {
    const popW = pop.offsetWidth;
    const popH = pop.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const sl = window.pageXOffset;
    const st = window.pageYOffset;

    let left = pageX + OFFSET;
    let top  = pageY + OFFSET;
    if (left + popW - sl > vw - 8) left = pageX - popW - OFFSET;
    if (top  + popH - st > vh - 8) top  = pageY - popH - OFFSET;

    pop.style.left = Math.max(sl + 4, left) + 'px';
    pop.style.top  = Math.max(st + 52, top) + 'px'; // ツールバー分を避ける
  });

  // ホバーで閉じる動作（ピンとポップオーバー間の移動に対応）
  pop.addEventListener('mouseenter', clearHoverTimer);
  pop.addEventListener('mouseleave', startHoverClose);

  return pop;
}

function closePopover() {
  document.getElementById('mu-popover')?.remove();
  document.getElementById('mu-overlay')?.classList.remove('mu-pop-open');
  Object.values(MU.pinElements).forEach(p => p.classList.remove('mu-sel'));
  MU.selectedId = null;
  MU_OBJECT_URLS.forEach(u => URL.revokeObjectURL(u));
  MU_OBJECT_URLS = [];
}

function clearHoverTimer() { clearTimeout(MU_HOVER_TIMER); }
function startHoverClose() {
  MU_HOVER_TIMER = setTimeout(() => closePopover(), 200);
}

// 新規コメント入力フォームをポップオーバーで表示
function openCommentForm(xPct, yPct, pageX, pageY) {
  showPopover(pageX, pageY, `
    <div class="mu-pop-hdr">
      <span class="mu-pop-ttl">新しいコメント</span>
      <button class="mu-pop-x" id="mu-pop-x">✕</button>
    </div>
    <div class="mu-pop-body">
      <textarea class="mu-ta" id="mu-new-text" placeholder="コメントを入力… @名前でメンション"></textarea>
      <div class="mu-dd" id="mu-new-dd"></div>
      <div class="mu-prev" id="mu-new-prev"></div>
      <div id="mu-send-err" class="mu-err"></div>
      <div class="mu-fa">
        <label class="mu-btn mu-img-btn">🖼 画像<input type="file" id="mu-new-img" accept="image/*" style="display:none"></label>
        <button class="mu-btn mu-sub" id="mu-new-submit">送信</button>
      </div>
    </div>`);

  // 新規コメントフォームはホバーで閉じない
  const pop = document.getElementById('mu-popover');
  pop.removeEventListener('mouseleave', startHoverClose);

  document.getElementById('mu-pop-x').addEventListener('click', closePopover);
  document.getElementById('mu-new-text').focus();

  let members = [], pendingImages = [];
  sb_getMembers().then(m => { members = m || []; });

  setupMention('mu-new-text', 'mu-new-dd', () => members, (name) => {
    const ta = document.getElementById('mu-new-text');
    const at = ta.value.lastIndexOf('@');
    ta.value = ta.value.slice(0, at) + '@' + name + ' ';
    document.getElementById('mu-new-dd').style.display = 'none';
    ta.focus();
  });

  document.getElementById('mu-new-img').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    pendingImages.push(file);
    addImgThumb('mu-new-prev', file);
  });

  document.getElementById('mu-new-submit').addEventListener('click', async () => {
    const text = document.getElementById('mu-new-text').value.trim();
    if (!text) return;
    const btn = document.getElementById('mu-new-submit');
    btn.disabled = true;
    btn.textContent = '送信中…';

    const result = await sb_addComment({
      site_url: window.location.href,
      x_percent: xPct, y_percent: yPct,
      text, author: MU.userName, assignee: extractMention(text),
      status: 'open', device: MU.device, image_paths: []
    });

    if (!result || !result[0]) {
      btn.disabled = false; btn.textContent = '送信';
      const err = document.getElementById('mu-send-err');
      if (err) err.textContent = '送信に失敗しました。再度お試しください。';
      return;
    }
    const newComment = result[0];

    try {
      if (pendingImages.length > 0) {
        const paths = [];
        for (const f of pendingImages) paths.push(await sb_uploadImage(f, newComment.id));
        await sb_updateImagePaths(newComment.id, paths);
        newComment.image_paths = paths;
      }
    } catch (_) {}

    MU.comments.push(newComment);
    MU_READ_IDS.add(newComment.id);
    chrome.storage.local.set({ [readKey()]: [...MU_READ_IDS] });
    addPin(newComment);
    updateBadge();
    closePopover();
  });
}

// ピンホバー時：コメント詳細をポップオーバーで表示
async function openCommentDetail(comment, pageX, pageY) {
  MU.selectedId = comment.id;
  Object.values(MU.pinElements).forEach(p => p.classList.remove('mu-sel'));
  MU.pinElements[comment.id]?.classList.add('mu-sel');

  // 未読→既読マーク（ローカル保存）
  if (!MU_READ_IDS.has(comment.id)) {
    MU_READ_IDS.add(comment.id);
    chrome.storage.local.set({ [readKey()]: [...MU_READ_IDS] });
    MU.pinElements[comment.id]?.classList.remove('mu-unread');
  }

  const replies = (await sb_getReplies(comment.id)) || [];
  const num = MU.comments.findIndex(c => c.id === comment.id) + 1;
  const stLabel = { open: '未対応', fixed: '対応済', verified: '確認完了', rejected: '差し戻し' };
  const stTrans = {
    open:     [{ to: 'fixed',    label: '対応済にする' }],
    fixed:    [{ to: 'verified', label: '確認完了にする' }, { to: 'rejected', label: '差し戻す' }],
    verified: [{ to: 'open',     label: '未対応に戻す'  }, { to: 'rejected', label: '差し戻す' }],
    rejected: [{ to: 'fixed',    label: '再対応済にする' }]
  };
  const transHtml = (stTrans[comment.status] || [])
    .map(t => `<button class="mu-st-btn mu-st-to-${t.to}" data-id="${comment.id}" data-next="${t.to}">${t.label}</button>`)
    .join('');

  const repliesHtml = replies.map(r => `
    <div class="mu-reply-card">
      <div class="mu-meta">
        <span class="mu-author">${escHtml(r.author)}</span>
        ${r.assignee ? `<span class="mu-to">→ @${escHtml(r.assignee)}</span>` : ''}
      </div>
      <div class="mu-text">${escHtml(r.text)}</div>
      ${r.image_paths?.length ? `<div class="mu-imgs">${r.image_paths.map(p => `<img src="${escHtml(p)}" class="mu-cimg" data-src="${escHtml(p)}">`).join('')}</div>` : ''}
    </div>`).join('');

  showPopover(pageX, pageY, `
    <div class="mu-pop-hdr">
      <span class="mu-pop-ttl">コメント #${num}</span>
      <button class="mu-pop-x" id="mu-pop-x">✕</button>
    </div>
    <div class="mu-pop-scroll">
      <div class="mu-main-card">
        <div class="mu-meta">
          <span class="mu-author">${escHtml(comment.author)}</span>
          ${comment.assignee ? `<span class="mu-to">→ @${escHtml(comment.assignee)}</span>` : ''}
          <span class="mu-st mu-st-${comment.status}">${stLabel[comment.status]}</span>
        </div>
        <div class="mu-text">${escHtml(comment.text)}</div>
        ${comment.image_paths?.length ? `<div class="mu-imgs">${comment.image_paths.map(p => `<img src="${escHtml(p)}" class="mu-cimg" data-src="${escHtml(p)}">`).join('')}</div>` : ''}
        <div class="mu-acts">
          ${transHtml}
          ${comment.author === MU.userName ? `<button class="mu-del-btn" id="mu-del-btn" data-id="${comment.id}">🗑 削除</button>` : ''}
        </div>
      </div>
      ${repliesHtml ? `<div class="mu-replies">${repliesHtml}</div>` : ''}
      <div class="mu-rform">
        <textarea class="mu-ta" id="mu-reply-text" placeholder="返信を入力…"></textarea>
        <div class="mu-dd" id="mu-reply-dd"></div>
        <div class="mu-prev" id="mu-reply-prev"></div>
        <div class="mu-fa">
          <label class="mu-btn mu-img-btn">🖼<input type="file" id="mu-reply-img" accept="image/*" style="display:none"></label>
          <button class="mu-btn mu-sub" id="mu-reply-submit">返信</button>
        </div>
      </div>
    </div>`);

  document.getElementById('mu-pop-x').addEventListener('click', closePopover);

  document.getElementById('mu-del-btn')?.addEventListener('click', async (e) => {
    if (!confirm('このコメントを削除しますか？（返信も一緒に削除されます）')) return;
    const cid = e.target.dataset.id;
    await sb_deleteComment(cid);
    MU.comments = MU.comments.filter(c => c.id !== cid);
    MU.pinElements[cid]?.remove();
    delete MU.pinElements[cid];
    updateBadge();
    closePopover();
  });

  document.querySelectorAll('#mu-popover .mu-cimg').forEach(img => {
    img.addEventListener('click', () => window.open(img.dataset.src));
  });

  document.querySelectorAll('#mu-popover .mu-st-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const newSt = e.currentTarget.dataset.next;
      const cid   = e.currentTarget.dataset.id;
      await sb_updateStatus(cid, newSt);
      const c = MU.comments.find(c => c.id === cid);
      if (c) {
        c.status = newSt;
        const pin = MU.pinElements[cid];
        if (pin) pin.className = `mu-pin mu-pin-${newSt} mu-sel`;
      }
      updateBadge();
      openCommentDetail({ ...comment, status: newSt }, pageX, pageY);
    });
  });

  let replyImages = [], members = [];
  sb_getMembers().then(m => { members = m || []; });

  setupMention('mu-reply-text', 'mu-reply-dd', () => members, (name) => {
    const ta = document.getElementById('mu-reply-text');
    const at = ta.value.lastIndexOf('@');
    ta.value = ta.value.slice(0, at) + '@' + name + ' ';
    document.getElementById('mu-reply-dd').style.display = 'none';
    ta.focus();
  });

  document.getElementById('mu-reply-img').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    replyImages.push(file);
    addImgThumb('mu-reply-prev', file);
  });

  document.getElementById('mu-reply-submit').addEventListener('click', async () => {
    const text = document.getElementById('mu-reply-text').value.trim();
    if (!text) return;
    const btn = document.getElementById('mu-reply-submit');
    btn.disabled = true; btn.textContent = '送信中…';

    const result = await sb_addComment({
      site_url: window.location.href,
      x_percent: comment.x_percent, y_percent: comment.y_percent,
      text, author: MU.userName, assignee: extractMention(text),
      status: 'open', device: MU.device, parent_id: comment.id, image_paths: []
    });

    if (!result || !result[0]) return;
    const newReply = result[0];
    if (replyImages.length > 0) {
      const paths = [];
      for (const f of replyImages) paths.push(await sb_uploadImage(f, newReply.id));
      await sb_updateImagePaths(newReply.id, paths);
    }
    openCommentDetail(comment, pageX, pageY);
  });
}

async function loadComments() {
  const comments = await sb_getComments(window.location.href, MU.device);
  MU.comments = comments || [];
  MU_CACHE[MU.device] = MU.comments;
  Object.values(MU.pinElements).forEach(el => el.remove());
  MU.pinElements = {};
  syncOverlaySize();
  MU.comments.forEach(addPin);
  updateBadge();
}

function addPin(comment) {
  const overlay = document.getElementById('mu-overlay');
  if (!overlay) return;

  const { w, h } = overlayDims();
  const num = MU.comments.findIndex(c => c.id === comment.id) + 1;
  const pin = document.createElement('div');
  pin.className = `mu-pin mu-pin-${comment.status}${MU_READ_IDS.has(comment.id) ? '' : ' mu-unread'}`;
  pin.dataset.id = comment.id;

  // ピクセル座標で配置（パーセントより正確）
  pin.style.left = ((comment.x_percent / 100) * w) + 'px';
  pin.style.top  = ((comment.y_percent / 100) * h) + 'px';
  pin.innerHTML  = `<span class="mu-pnum">${num}</span>`;
  pin.title = `${comment.author}: ${comment.text.slice(0, 40)}`;

  const pinPageX = (comment.x_percent / 100) * w;
  const pinPageY = (comment.y_percent / 100) * h;

  // ホバーでポップオーバー表示
  pin.addEventListener('mouseenter', () => {
    clearHoverTimer();
    openCommentDetail(comment, pinPageX, pinPageY);
  });
  pin.addEventListener('mouseleave', startHoverClose);

  overlay.appendChild(pin);
  MU.pinElements[comment.id] = pin;
}

function setupMention(textareaId, dropdownId, getMembers, onSelect) {
  const ta = document.getElementById(textareaId);
  if (!ta) return;
  ta.addEventListener('input', () => {
    const val = ta.value;
    const at  = val.lastIndexOf('@');
    const dd  = document.getElementById(dropdownId);
    if (at !== -1) {
      const filtered = getMembers().filter(m => m.name.toLowerCase().includes(val.slice(at + 1).toLowerCase()));
      if (filtered.length) {
        dd.style.display = 'block';
        dd.innerHTML = filtered.map(m => `<div class="mu-mi" data-name="${escHtml(m.name)}">${escHtml(m.name)}</div>`).join('');
        dd.querySelectorAll('.mu-mi').forEach(el => el.addEventListener('click', () => onSelect(el.dataset.name)));
      } else { dd.style.display = 'none'; }
    } else { if (dd) dd.style.display = 'none'; }
  });
}

function addImgThumb(previewId, file) {
  const prev = document.getElementById(previewId);
  if (!prev) return;
  const url = URL.createObjectURL(file);
  MU_OBJECT_URLS.push(url);
  const div = document.createElement('div');
  div.className = 'mu-thumb';
  div.innerHTML = `<img src="${url}">`;
  prev.appendChild(div);
}

async function setDevice(device) {
  MU.device = device;
  chrome.storage.local.set({ mu_device: device });
  document.getElementById('mu-dev-pc')?.classList.toggle('mu-seg-on', device === 'pc');
  document.getElementById('mu-dev-mobile')?.classList.toggle('mu-seg-on', device === 'mobile');
  if (MU.active) {
    if (MU_CACHE[device]) {
      MU.comments = MU_CACHE[device];
      Object.values(MU.pinElements).forEach(el => el.remove());
      MU.pinElements = {};
      syncOverlaySize();
      MU.comments.forEach(addPin);
      updateBadge();
    } else {
      await loadComments();
    }
    closePopover();
  }
}

function updateBadge() {
  const counts = document.getElementById('mu-counts');
  if (!counts) return;
  const labels = { open: '未対応', fixed: '対応済', rejected: '差し戻し', verified: '確認完了' };
  const tally = { open: 0, fixed: 0, rejected: 0, verified: 0 };
  MU.comments.forEach(c => { if (tally[c.status] !== undefined) tally[c.status]++; });
  counts.innerHTML = Object.entries(tally)
    .filter(([, n]) => n > 0)
    .map(([st, n]) => `<span class="mu-ci mu-ci-${st}">${labels[st]} ${n}</span>`)
    .join('');
}

function extractMention(text) {
  const m = text.match(/@(\S+)/);
  return m ? m[1] : null;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
