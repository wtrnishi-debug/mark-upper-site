const MU = {
  active: false,
  device: 'pc',
  userName: '',
  comments: [],
  pinElements: {},
  selectedId: null,
  fixedWidth: false,
  toolbarMode: 'top',
  sessionId: null,
  pageUrl: '',
  commenting: false,
  panelOpen: true,
  jumpToId: null,
  theme: 'dark',
  vpCustomW: null,
  vpCustomScale: null,
  vpCustomH: null,
};

let MU_HOVER_TIMER = null;

(async function init() {
  const stored = await chrome.storage.local.get(['mu_username', 'mu_device', 'mu_fixed_width', 'mu_jump_to', 'mu_theme']);
  if (stored.mu_username) MU.userName = stored.mu_username;
  if (stored.mu_device) MU.device = stored.mu_device;
  if (stored.mu_fixed_width) MU.fixedWidth = true;
  if (stored.mu_theme) MU.theme = stored.mu_theme;
  chrome.runtime.onMessage.addListener(handleMessage);
  if (stored.mu_jump_to) {
    MU.jumpToId = stored.mu_jump_to;
    chrome.storage.local.remove('mu_jump_to');
    await activate();
  }
})();

function handleMessage(msg, sender, sendResponse) {
  if (msg.type === 'GET_STATE') {
    sendResponse({ active: MU.active, device: MU.device, userName: MU.userName, commentCount: MU.comments.length, sessionId: MU.sessionId });
    return true;
  }
  if (msg.type === 'TOGGLE_ACTIVE') {
    MU.active ? deactivate() : activate();
    sendResponse({ active: MU.active });
    return true;
  }
  if (msg.type === 'SET_USERNAME') {
    MU.userName = msg.name;
    chrome.storage.local.set({ mu_username: msg.name });
    sb_addMember(msg.name);
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'SET_DEVICE') {
    setDevice(msg.device);
    sendResponse({ ok: true });
    return true;
  }
}

let MU_POLL_TIMER = null;
let MU_ORIG_MR = null;
let MU_SITE_FIXED_PANEL = [];
let MU_READ_IDS = new Set();
let MU_OBJECT_URLS = [];
const MU_CACHE = { pc: null, mobile: null };
const MU_MAX_FILE = 10 * 1024 * 1024;
let MU_FILE_OPEN = false;
let MU_DETAIL_SEQ = 0;
let MU_DRAG_GUARD_UNTIL = 0;

function readKey() { return 'mu_read_' + MU.userName; }

const MU_TOOLBAR_H  = 56;
const MU_VPBAR_H    = 32;
const MU_SIDE_GAP   = 12;
const MU_BOTTOM_GAP = 16;

function muVpBgColor() {
  const bodyBg = getComputedStyle(document.body).backgroundColor;
  if (bodyBg && bodyBg !== 'rgba(0, 0, 0, 0)' && bodyBg !== 'transparent') return bodyBg;
  const htmlBg = getComputedStyle(document.documentElement).backgroundColor;
  if (htmlBg && htmlBg !== 'rgba(0, 0, 0, 0)' && htmlBg !== 'transparent') return htmlBg;
  return '#fff';
}

// ウィンドウサイズを変えずに body を transform でシミュレート
function buildVpStyleText(tx, ty, targetW, scale, minH, vpBg) {
  const scaledW = Math.round(targetW * scale);
  const scaledH = Math.round(minH * scale);
  return [
    `html.mu-vp-active { background: linear-gradient(${vpBg}, ${vpBg}) ${Math.round(tx)}px ${Math.round(ty)}px / ${scaledW}px ${scaledH}px no-repeat, #262626 !important; }`,
    'body.mu-vp-body {',
    `  width: ${targetW}px !important; min-width: 0 !important; max-width: none !important;`,
    '  margin: 0 !important;',
    `  transform: translateX(${tx}px) translateY(${ty}px) scale(${scale}) !important;`,
    '  transform-origin: top left !important;',
    '  overflow-x: clip !important;',
    '  box-shadow: 0 0 0 1px rgba(255,255,255,.1) !important;',
    '}',
  ].join('\n');
}

function applyViewportSim() {
  removeViewportSim();
  const targetW     = MU.vpCustomW || (MU.device === 'mobile' ? 375 : 1366);
  const panelW      = MU.panelOpen ? 210 : 0;
  const availW      = window.innerWidth - panelW;
  const innerW      = Math.max(1, availW - MU_SIDE_GAP * 2);
  const autoScale   = Math.min(innerW / targetW, 1);
  const scale       = MU.vpCustomScale !== null ? MU.vpCustomScale : autoScale;
  const scaledW     = targetW * scale;
  const tx          = MU_SIDE_GAP + Math.max(0, (innerW - scaledW) / 2);
  const ty          = MU_TOOLBAR_H + (MU.toolbarMode === 'top' ? MU_VPBAR_H : 0);
  const defaultMinH = Math.round((window.innerHeight - ty - MU_BOTTOM_GAP) / scale);
  const minH        = MU.vpCustomH !== null ? MU.vpCustomH : defaultMinH;
  const vpBg        = muVpBgColor();
  const style = document.createElement('style');
  style.id = 'mu-vp-style';
  style.textContent = buildVpStyleText(tx, ty, targetW, scale, minH, vpBg);
  document.head.appendChild(style);
  document.documentElement.classList.add('mu-vp-active');
  document.body.classList.add('mu-vp-body');
  // ピンの逆補正用（body が scale される分、ピンは 1/scale で拡大して見た目を一定に）
  document.documentElement.style.setProperty('--mu-pin-inv', scale ? 1 / scale : 1);
  if (MU.toolbarMode === 'top') {
    buildVpBar(tx, scaledW, targetW, scale);
    buildVpHandle(tx, scaledW, targetW, scale, ty, panelW, minH);
    buildVpBotHandle(tx, scaledW, targetW, scale, ty, minH);
    buildVpCorner(tx, scaledW, targetW, scale, ty, minH);
  }
  window._mu_vp_resize = () => applyViewportSim();
  window.addEventListener('resize', window._mu_vp_resize);
}

function buildVpBar(tx, scaledW, targetW, scale) {
  document.getElementById('mu-vp-bar')?.remove();
  const bar = document.createElement('div');
  bar.id = 'mu-vp-bar';
  bar.style.cssText = `left:${Math.round(tx)}px!important;width:${Math.round(scaledW)}px!important`;
  const pct = Math.round(scale * 100);
  bar.innerHTML = `
    <span class="mu-vpb-lbl">幅</span>
    <input class="mu-vpb-inp" id="mu-vpb-px" type="number" value="${targetW}" min="320" max="1920">
    <span class="mu-vpb-unit">px</span>
    <span class="mu-vpb-sep">|</span>
    <input class="mu-vpb-inp" id="mu-vpb-pct" type="number" value="${pct}" min="10" max="200">
    <span class="mu-vpb-unit">%</span>`;
  document.documentElement.appendChild(bar);
  const pxInp  = bar.querySelector('#mu-vpb-px');
  const pctInp = bar.querySelector('#mu-vpb-pct');
  const applyPx = () => {
    const v = parseInt(pxInp.value);
    if (v >= 320 && v <= 1920) { MU.vpCustomW = v; MU.vpCustomScale = null; applyViewportSim(); }
  };
  const applyPct = () => {
    const v = parseInt(pctInp.value);
    if (v >= 10 && v <= 200) { MU.vpCustomScale = v / 100; applyViewportSim(); }
  };
  pxInp.addEventListener('change', applyPx);
  pxInp.addEventListener('keydown', e => { if (e.key === 'Enter') applyPx(); });
  pctInp.addEventListener('change', applyPct);
  pctInp.addEventListener('keydown', e => { if (e.key === 'Enter') applyPct(); });
}

const _GRIP_V = `<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;gap:3px;pointer-events:none"><div style="width:3px;height:3px;border-radius:50%;background:rgba(255,255,255,.55)"></div><div style="width:3px;height:3px;border-radius:50%;background:rgba(255,255,255,.55)"></div><div style="width:3px;height:3px;border-radius:50%;background:rgba(255,255,255,.55)"></div></div>`;
const _GRIP_H = `<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);display:flex;flex-direction:row;align-items:center;gap:3px;pointer-events:none"><div style="width:3px;height:3px;border-radius:50%;background:rgba(255,255,255,.55)"></div><div style="width:3px;height:3px;border-radius:50%;background:rgba(255,255,255,.55)"></div><div style="width:3px;height:3px;border-radius:50%;background:rgba(255,255,255,.55)"></div></div>`;

function _handleHover(el, on) {
  if (on) {
    el.style.setProperty('background', 'rgba(124,58,237,.35)', 'important');
    el.style.setProperty('border-color', 'rgba(124,58,237,.7)', 'important');
  } else {
    el.style.setProperty('background', 'rgba(255,255,255,.05)', 'important');
    el.style.setProperty('border-color', 'rgba(255,255,255,.18)', 'important');
  }
}

function buildVpHandle(tx, scaledW, targetW, scale, ty, panelW, minH) {
  document.getElementById('mu-vp-handle')?.remove();
  const h = document.createElement('div');
  h.id = 'mu-vp-handle';
  h.innerHTML = _GRIP_V;
  h.style.cssText = `position:fixed!important;top:${ty}px!important;left:${Math.round(tx + scaledW)}px!important;width:12px!important;height:${Math.round(minH * scale)}px!important;cursor:ew-resize!important;z-index:2147483645!important;background:rgba(255,255,255,.05)!important;border-left:1px solid rgba(255,255,255,.18)!important;box-sizing:border-box!important;transition:background .15s,border-color .15s!important;`;
  document.documentElement.appendChild(h);
  h.addEventListener('mouseenter', () => _handleHover(h, true));
  h.addEventListener('mouseleave', () => _handleHover(h, false));
  h.addEventListener('mousedown', e => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = targetW;
    let finalW   = targetW;
    const vpBg   = muVpBgColor();
    const onMove = ev => {
      const newW      = Math.round(Math.max(100, startW + (ev.clientX - startX) / scale));
      finalW          = newW;
      const newScaled = newW * scale;
      const styleEl   = document.getElementById('mu-vp-style');
      if (styleEl) styleEl.textContent = buildVpStyleText(tx, ty, newW, scale, minH, vpBg);
      h.style.setProperty('left', `${Math.round(tx + newScaled)}px`, 'important');
      document.getElementById('mu-vp-bot-handle')?.style.setProperty('width', `${Math.round(newScaled)}px`, 'important');
      document.getElementById('mu-vp-corner')?.style.setProperty('left', `${Math.round(tx + newScaled)}px`, 'important');
      const pxInp = document.getElementById('mu-vpb-px');
      if (pxInp) pxInp.value = newW;
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      MU.vpCustomW     = finalW;
      MU.vpCustomScale = scale;
      applyViewportSim();
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

function buildVpBotHandle(tx, scaledW, targetW, scale, ty, minH) {
  document.getElementById('mu-vp-bot-handle')?.remove();
  const h = document.createElement('div');
  h.id = 'mu-vp-bot-handle';
  h.innerHTML = _GRIP_H;
  const top = Math.round(ty + minH * scale);
  h.style.cssText = `position:fixed!important;top:${top}px!important;left:${Math.round(tx)}px!important;width:${Math.round(scaledW)}px!important;height:12px!important;cursor:ns-resize!important;z-index:2147483645!important;background:rgba(255,255,255,.05)!important;border-top:1px solid rgba(255,255,255,.18)!important;box-sizing:border-box!important;transition:background .15s,border-color .15s!important;`;
  document.documentElement.appendChild(h);
  h.addEventListener('mouseenter', () => _handleHover(h, true));
  h.addEventListener('mouseleave', () => _handleHover(h, false));
  h.addEventListener('mousedown', e => {
    e.preventDefault();
    const startY   = e.clientY;
    const startH   = minH;
    let finalH     = minH;
    const vpBg     = muVpBgColor();
    const onMove   = ev => {
      const newH    = Math.max(1, Math.round(startH + (ev.clientY - startY) / scale));
      finalH        = newH;
      const newTop  = Math.round(ty + newH * scale);
      const styleEl = document.getElementById('mu-vp-style');
      if (styleEl) styleEl.textContent = buildVpStyleText(tx, ty, targetW, scale, newH, vpBg);
      h.style.setProperty('top', `${newTop}px`, 'important');
      document.getElementById('mu-vp-handle')?.style.setProperty('height', `${Math.round(newH * scale)}px`, 'important');
      document.getElementById('mu-vp-corner')?.style.setProperty('top', `${newTop}px`, 'important');
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      MU.vpCustomH = finalH;
      applyViewportSim();
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

function buildVpCorner(tx, scaledW, targetW, scale, ty, minH) {
  document.getElementById('mu-vp-corner')?.remove();
  const h = document.createElement('div');
  h.id = 'mu-vp-corner';
  const left = Math.round(tx + scaledW);
  const top  = Math.round(ty + minH * scale);
  h.innerHTML = `<svg width="8" height="8" viewBox="0 0 8 8" fill="none" style="pointer-events:none;opacity:.7"><path d="M1.5 6.5L6.5 1.5M6.5 1.5L6.5 6.5L1.5 6.5" stroke="white" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  h.style.cssText = `position:fixed!important;top:${top}px!important;left:${left}px!important;width:16px!important;height:16px!important;cursor:nwse-resize!important;z-index:2147483645!important;background:rgba(255,255,255,.07)!important;border-top:1px solid rgba(255,255,255,.18)!important;border-left:1px solid rgba(255,255,255,.18)!important;box-sizing:border-box!important;display:flex!important;align-items:center!important;justify-content:center!important;transition:background .15s!important;`;
  document.documentElement.appendChild(h);
  h.addEventListener('mouseenter', () => { h.style.setProperty('background', 'rgba(124,58,237,.45)', 'important'); });
  h.addEventListener('mouseleave', () => { h.style.setProperty('background', 'rgba(255,255,255,.07)', 'important'); });
  h.addEventListener('mousedown', e => {
    e.preventDefault();
    const startX = e.clientX;
    const startY = e.clientY;
    const startW = targetW;
    const startH = minH;
    let finalW   = targetW;
    let finalH   = minH;
    const vpBg   = muVpBgColor();
    const onMove = ev => {
      const newW      = Math.round(Math.max(100, startW + (ev.clientX - startX) / scale));
      const newH      = Math.max(1, Math.round(startH + (ev.clientY - startY) / scale));
      finalW          = newW;
      finalH          = newH;
      const newScaled = newW * scale;
      const newTop    = Math.round(ty + newH * scale);
      const styleEl   = document.getElementById('mu-vp-style');
      if (styleEl) styleEl.textContent = buildVpStyleText(tx, ty, newW, scale, newH, vpBg);
      const rh = document.getElementById('mu-vp-handle');
      if (rh) { rh.style.setProperty('left', `${Math.round(tx + newScaled)}px`, 'important'); rh.style.setProperty('height', `${Math.round(newH * scale)}px`, 'important'); }
      const bh = document.getElementById('mu-vp-bot-handle');
      if (bh) { bh.style.setProperty('top', `${newTop}px`, 'important'); bh.style.setProperty('width', `${Math.round(newScaled)}px`, 'important'); }
      h.style.setProperty('top', `${newTop}px`, 'important');
      h.style.setProperty('left', `${Math.round(tx + newScaled)}px`, 'important');
      const pxInp = document.getElementById('mu-vpb-px');
      if (pxInp) pxInp.value = newW;
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      MU.vpCustomW     = finalW;
      MU.vpCustomScale = scale;
      MU.vpCustomH     = finalH;
      applyViewportSim();
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  });
}

function removeViewportSim() {
  document.getElementById('mu-vp-style')?.remove();
  document.getElementById('mu-vp-bar')?.remove();
  document.getElementById('mu-vp-handle')?.remove();
  document.getElementById('mu-vp-bot-handle')?.remove();
  document.getElementById('mu-vp-corner')?.remove();
  document.documentElement.classList.remove('mu-vp-active');
  document.body.classList.remove('mu-vp-body');
  document.documentElement.style.setProperty('--mu-pin-inv', 1);
  if (window._mu_vp_resize) {
    window.removeEventListener('resize', window._mu_vp_resize);
    delete window._mu_vp_resize;
  }
}

// 現在の仮想ビューポートのパラメータ（tx/ty/scale）を返す。未使用時は null。
function getVpSimParams() {
  if (!document.body.classList.contains('mu-vp-body')) return null;
  const panelW    = MU.panelOpen ? 210 : 0;
  const availW    = window.innerWidth - panelW;
  const innerW    = Math.max(1, availW - MU_SIDE_GAP * 2);
  const targetW   = MU.vpCustomW || (MU.device === 'mobile' ? 375 : 1366);
  const autoScale = Math.min(innerW / targetW, 1);
  const scale     = MU.vpCustomScale !== null ? MU.vpCustomScale : autoScale;
  const scaledW   = targetW * scale;
  const tx        = MU_SIDE_GAP + Math.max(0, (innerW - scaledW) / 2);
  const ty        = MU_TOOLBAR_H + (MU.toolbarMode === 'top' ? MU_VPBAR_H : 0);
  return { tx, ty, scale };
}

// ドキュメント座標（rect + scrollOffset）をbody-local CSS座標に変換する。
// body に transform があるとき、getBoundingClientRect()+scroll はドキュメント座標を返す。
// これはbody-local座標（CSS left/top に使う値）と異なるため変換が必要。
function vpToBodyLocal(docX, docY) {
  const vp = getVpSimParams();
  if (vp) return { pageX: (docX - vp.tx) / vp.scale, pageY: (docY - vp.ty) / vp.scale };
  const overlay = document.getElementById('mu-overlay');
  if (!overlay) return { pageX: docX, pageY: docY };
  const oRect = overlay.getBoundingClientRect();
  return {
    pageX: docX - (oRect.left + window.pageXOffset),
    pageY: docY - (oRect.top  + window.pageYOffset),
  };
}

// body-local座標を画面（fixed）座標に変換する。
function vpToScreen(bodyX, bodyY) {
  const vp = getVpSimParams();
  if (!vp) return { x: bodyX - window.pageXOffset, y: bodyY - window.pageYOffset };
  return {
    x: bodyX * vp.scale + vp.tx - window.pageXOffset,
    y: bodyY * vp.scale + vp.ty - window.pageYOffset,
  };
}

// Mobileモード時はツールバーをコンパクト表示に切り替える
function updateToolbarLayout() {
  document.getElementById('mu-toolbar')?.classList.toggle('mu-narrow', MU.device === 'mobile');
}

async function activate() {
  MU.active = true;
  applyTheme();
  MU.pageUrl = location.href;
  if (!MU.sessionId) {
    const session = await sb_getOrCreateSession(location.hostname);
    MU.sessionId = session?.id || null;
  }
  {
    const current = parseInt(getComputedStyle(document.body).marginTop) || 0;
    const style = document.createElement('style');
    style.id = 'mu-offset';
    style.textContent = `body{position:relative!important;margin-top:${current + 56}px!important}`;
    document.head.appendChild(style);
  }
  buildUI();
  applyViewportSim();
  updateToolbarLayout();
  const readData = await chrome.storage.local.get(readKey());
  MU_READ_IDS = new Set(readData[readKey()] || []);
  await loadComments();
  startPolling();
  const upd = await chrome.storage.local.get(['mu_update_version', 'mu_update_download']);
  if (upd.mu_update_version) showUpdatePill(upd.mu_update_version, upd.mu_update_download);
}

function deactivate() {
  MU.active = false;
  removeViewportSim();
  document.documentElement.classList.remove('mu-light');
  try { chrome.runtime.sendMessage({ type: 'SET_BADGE', text: '' }); } catch (_) {}
  stopPolling();
  document.getElementById('mu-offset')?.remove();
  removePanelOffset();
  window.removeEventListener('resize', syncOverlaySize);
  closeSitesModal();
  ['mu-toolbar', 'mu-overlay', 'mu-nav', 'mu-panel'].forEach(id => document.getElementById(id)?.remove());
}

function startPolling() {
  stopPolling();
  MU_POLL_TIMER = setInterval(pollComments, 20000);
}

function stopPolling() {
  clearInterval(MU_POLL_TIMER);
  MU_POLL_TIMER = null;
}

async function pollComments() {
  if (!MU.active || !MU.sessionId) return;
  try {
    const fresh = await sb_getComments(MU.sessionId, MU.pageUrl, MU.device);
    if (!fresh) return;
    const currentIds = new Set(MU.comments.map(c => c.id));
    const newCount = fresh.filter(c => !currentIds.has(c.id)).length;
    if (newCount > 0) showNotify(newCount, fresh);
  } catch (_) {}
}

function showNotify(count, fresh) {
  const existing = document.getElementById('mu-notify-btn');
  if (existing) { existing.dataset.fresh = JSON.stringify(fresh); existing.textContent = `🔔 ${count}件の新着`; return; }
  const btn = document.createElement('button');
  btn.id = 'mu-notify-btn';
  btn.className = 'mu-btn mu-notify-btn';
  btn.textContent = `🔔 ${count}件の新着`;
  btn.dataset.fresh = JSON.stringify(fresh);
  btn.addEventListener('click', async () => {
    const data = JSON.parse(btn.dataset.fresh);
    btn.remove();
    Object.values(MU.pinElements).forEach(el => el.remove());
    MU.pinElements = {};
    MU.comments = data;
    MU_CACHE[MU.device] = MU.comments;
    syncOverlaySize();
    MU.comments.forEach(addPin);
    updateBadge();
    closePopover();
  });
  document.getElementById('mu-toolbar')?.querySelector('.mu-right')?.prepend(btn);
}

// オーバーレイのサイズをページ全体に合わせ、ピン位置も再計算
function syncOverlaySize() {
  const overlay = document.getElementById('mu-overlay');
  if (!overlay) return;
  const w = Math.max(document.documentElement.scrollWidth, document.body.scrollWidth);
  const h = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);
  overlay.style.width  = w + 'px';
  overlay.style.height = h + 'px';

  // body が position:relative 等のとき overlay の含有ブロックが body になり、
  // MU が付加した margin-top 分だけ overlay の原点 (top:0) がずれる。
  // body の ICB 原点からのオフセットを打ち消して overlay を常に doc(0,0) 基準にする。
  // vp-sim 中は body に transform があり座標系が異なるため補正不要。
  if (!getVpSimParams() && getComputedStyle(document.body).position !== 'static') {
    const br = document.body.getBoundingClientRect();
    const bTop  = Math.round(br.top  + window.pageYOffset);
    const bLeft = Math.round(br.left + window.pageXOffset);
    overlay.style.setProperty('top',  (-bTop)  + 'px', 'important');
    overlay.style.setProperty('left', (-bLeft) + 'px', 'important');
  } else {
    overlay.style.setProperty('top',  '0px', 'important');
    overlay.style.setProperty('left', '0px', 'important');
  }

  repositionPins();
}

function overlayDims() {
  const overlay = document.getElementById('mu-overlay');
  return {
    w: parseFloat(overlay?.style.width)  || document.documentElement.scrollWidth,
    h: parseFloat(overlay?.style.height) || document.documentElement.scrollHeight
  };
}

// ハッシュ文字列や自動生成されたID/クラスを除外して安定したものだけ使う
function muIsStable(s) {
  if (!s) return false;
  if (!/^[a-zA-Z][\w-]*$/.test(s)) return false;       // 記号始まり・特殊文字を除外
  if (/[a-f0-9]{5,}/i.test(s)) return false;            // 連続した16進ハッシュを除外
  if (/^(css|sc|jsx|emotion|chakra|mui)-/i.test(s)) return false; // CSS-in-JS自動クラス
  if (s.length > 40) return false;
  return true;
}

// 要素のCSSセレクタを生成（クラス名に依存せず構造パスで生成）
function getCssSelector(el) {
  if (muIsStable(el.id)) return '#' + CSS.escape(el.id);
  const parts = [];
  let cur = el;
  while (cur && cur !== document.body && cur !== document.documentElement && parts.length < 10) {
    if (muIsStable(cur.id)) { parts.unshift('#' + CSS.escape(cur.id)); break; }
    const parent = cur.parentElement;
    if (!parent) break;
    const tag = cur.tagName.toLowerCase();
    const same = Array.from(parent.children).filter(s => s.tagName === cur.tagName);
    parts.unshift(same.length > 1 ? `${tag}:nth-of-type(${same.indexOf(cur) + 1})` : tag);
    cur = parent;
  }
  return parts.join(' > ');
}

// ---- 要素の「指紋（fingerprint）」方式 ----
// 位置（nth-of-type）ではなく、要素の中身・属性で要素を識別する。
// レスポンシブで要素の並び順や階層が多少変わっても、
// 「同じ中身を持つ要素」を採点で見つけられるようにするのが狙い。

// 要素から短く正規化したテキストを取り出す
function muElText(el) {
  const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
  return t.length > 80 ? t.slice(0, 80) : t;
}

// 要素1個分の特徴を集める
function muNodeFeatures(el) {
  const f = { tag: el.tagName.toLowerCase() };
  if (muIsStable(el.id)) f.id = el.id;
  const cls = (el.className && typeof el.className === 'string' ? el.className : '')
    .split(/\s+/).filter(muIsStable).slice(0, 4);
  if (cls.length) f.cls = cls;
  // 識別に役立つ属性（リンク先・画像・ボタン種別・data-*など）
  const attrs = {};
  for (const name of ['href', 'src', 'alt', 'type', 'name', 'role', 'aria-label', 'data-testid', 'placeholder']) {
    const v = el.getAttribute && el.getAttribute(name);
    if (v && v.length < 120) attrs[name] = v;
  }
  if (Object.keys(attrs).length) f.attrs = attrs;
  const txt = muElText(el);
  if (txt) f.text = txt;
  // 親の何番目か（同じタグの中での順番）。最後の手がかりとして保持
  const parent = el.parentElement;
  if (parent) {
    const same = Array.from(parent.children).filter(s => s.tagName === el.tagName);
    f.idx = same.indexOf(el);
    f.total = same.length;
  }
  return f;
}

// クリックした要素＋先祖数段ぶんの指紋を作る
function buildFingerprint(el) {
  const chain = [];
  let cur = el;
  let depth = 0;
  while (cur && cur !== document.body && cur !== document.documentElement && depth < 5) {
    chain.push(muNodeFeatures(cur));
    cur = cur.parentElement;
    depth++;
  }
  return chain; // [対象要素, 親, 祖父, ...]
}

// 1要素と保存済み特徴の一致度を採点（0〜100）
function muScoreNode(el, f) {
  if (!el || el.tagName.toLowerCase() !== f.tag) return -1;
  let score = 5; // タグ一致の基礎点
  if (f.id && el.id === f.id) score += 60;
  if (f.attrs) {
    for (const [k, v] of Object.entries(f.attrs)) {
      if ((el.getAttribute && el.getAttribute(k)) === v) score += 18;
    }
  }
  if (f.cls) {
    const elCls = (el.className && typeof el.className === 'string' ? el.className : '').split(/\s+/);
    const hit = f.cls.filter(c => elCls.includes(c)).length;
    score += hit * 12;
  }
  if (f.text) {
    const t = muElText(el);
    if (t === f.text) score += 40;
    else if (t && (t.includes(f.text) || f.text.includes(t))) score += 20;
  }
  // 順番が一致すればわずかに加点（弱い手がかり）
  if (f.idx != null && el.parentElement) {
    const same = Array.from(el.parentElement.children).filter(s => s.tagName === el.tagName);
    if (same.indexOf(el) === f.idx && same.length === f.total) score += 6;
  }
  return score;
}

// 指紋からページ内の最も近い要素を探す
function findByFingerprint(chain) {
  if (!Array.isArray(chain) || !chain.length) return null;
  const target = chain[0];

  // 候補を絞る：対象要素と同じタグの要素すべて
  let candidates = Array.from(document.querySelectorAll(target.tag));
  if (candidates.length > 4000) return null; // 巨大ページでの暴走防止

  let best = null, bestScore = -1;
  for (const el of candidates) {
    if ((el.id || '').startsWith('mu-') || el.closest('#mu-overlay,#mu-toolbar,#mu-nav')) continue;
    let score = muScoreNode(el, target);
    if (score < 0) continue;
    // 先祖もたどって一致を確認（構造のズレに強くするため、
    // 親が完全一致しなくても祖父が合えば加点していく）
    let anc = el.parentElement;
    for (let i = 1; i < chain.length && anc; i++) {
      // 数段ぶん上に向かって、一番合う先祖を探す
      let ancBest = -1, hops = 0, probe = anc;
      while (probe && hops < 3) {
        const s = muScoreNode(probe, chain[i]);
        if (s > ancBest) ancBest = s;
        probe = probe.parentElement;
        hops++;
      }
      if (ancBest > 0) score += ancBest * 0.4; // 先祖の一致は弱めに反映
      anc = anc.parentElement;
    }
    if (score > bestScore) { bestScore = score; best = el; }
  }
  // 最低限の確からしさがある場合のみ採用
  // （対象タグ一致＋テキストか属性かIDのどれかが合っている水準）
  return bestScore >= 25 ? best : null;
}

// ============================================================
// ★ 新方式A：テキストアンカー方式
// ------------------------------------------------------------
// 「クリックした要素そのもの」を探すのをやめ、クリック地点の近くに
// “実際に画面に表示されている文章”を目印（アンカー）として記録する。
// 文章の中身は画面幅が変わっても基本そのまま残るので、
// クラス名やDOM階層が総入れ替えになっても目印を再発見できる。
// 復元時は「目印の文章」を探し、そこからの位置関係でピンを置き直す。
// ============================================================

// 画面に見えている「地の文」テキストノードを集める。
// （短すぎる文字・スクリプト類・非表示要素・拡張機能自身のUIは除外）
function muCollectTextAnchors() {
  const anchors = [];
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const txt = (node.nodeValue || '').replace(/\s+/g, ' ').trim();
      if (txt.length < 5) return NodeFilter.FILTER_REJECT;       // 短すぎる文字は目印にならない
      const p = node.parentElement;
      if (!p) return NodeFilter.FILTER_REJECT;
      if ((p.id || '').startsWith('mu-') || p.closest('#mu-overlay,#mu-toolbar,#mu-nav')) return NodeFilter.FILTER_REJECT;
      const tag = p.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  let n;
  while ((n = walker.nextNode())) {
    if (anchors.length > 6000) break; // 巨大ページでの暴走防止
    const range = document.createRange();
    range.selectNodeContents(n);
    const rect = range.getBoundingClientRect();
    if (rect.width + rect.height === 0) continue; // 非表示
    const txt = (n.nodeValue || '').replace(/\s+/g, ' ').trim();
    anchors.push({
      text: txt.length > 120 ? txt.slice(0, 120) : txt,
      cx: rect.left + rect.width / 2 + window.pageXOffset,
      cy: rect.top + rect.height / 2 + window.pageYOffset
    });
  }
  return anchors;
}

// クリック地点の周辺にある文章アンカーを最大3つ選び、
// ピンとの位置関係（縦のズレ・横のズレ）を記録する。
function buildTextAnchors(pageX, pageY) {
  const all = muCollectTextAnchors();
  if (!all.length) return null;
  // クリック地点に近い順に並べる
  all.sort((a, b) => {
    const da = (a.cx - pageX) ** 2 + (a.cy - pageY) ** 2;
    const db = (b.cx - pageX) ** 2 + (b.cy - pageY) ** 2;
    return da - db;
  });
  const picked = [];
  const seen = new Set();
  for (const a of all) {
    if (seen.has(a.text)) continue; // 同じ文言は1つだけ（ナビの繰り返しなどを避ける）
    seen.add(a.text);
    picked.push({ text: a.text, dx: Math.round(pageX - a.cx), dy: Math.round(pageY - a.cy) });
    if (picked.length >= 3) break;
  }
  return picked.length ? picked : null;
}

// 文章アンカーからピンのページ座標を復元する。
// 記録した複数の目印それぞれが指す座標を求め、平均してブレを抑える。
// ページ内に同じ文言が複数ある場合は、各目印が示す座標が
// 互いに近いものだけを採用する（多数決）。
function findByTextAnchors(textAnchors) {
  if (!Array.isArray(textAnchors) || !textAnchors.length) return null;
  const all = muCollectTextAnchors();
  if (!all.length) return null;
  const byText = new Map();
  for (const a of all) {
    if (!byText.has(a.text)) byText.set(a.text, []);
    byText.get(a.text).push(a);
  }
  // 各目印が指す候補座標を集める
  const guesses = [];
  for (const ta of textAnchors) {
    let hits = byText.get(ta.text);
    if (!hits) {
      // 完全一致がなければ前方一致でゆるく探す（文章が一部編集された場合の保険）
      for (const [txt, list] of byText) {
        if (txt.startsWith(ta.text.slice(0, 20)) || ta.text.startsWith(txt.slice(0, 20))) { hits = list; break; }
      }
    }
    if (!hits || !hits.length) continue;
    // 同じ文言が複数あるときは全候補を出しておき、後でまとまりを見る
    for (const h of hits) guesses.push({ x: h.cx + ta.dx, y: h.cy + ta.dy });
  }
  if (!guesses.length) return null;
  if (guesses.length === 1) return { pageX: guesses[0].x, pageY: guesses[0].y };
  // 互いに近い候補同士でいちばん大きなまとまりを探す（多数決）
  let bestCluster = [];
  for (const g of guesses) {
    const cluster = guesses.filter(o =>
      Math.abs(o.x - g.x) < 60 && Math.abs(o.y - g.y) < 60);
    if (cluster.length > bestCluster.length) bestCluster = cluster;
  }
  const use = bestCluster.length ? bestCluster : guesses;
  const avgX = use.reduce((s, g) => s + g.x, 0) / use.length;
  const avgY = use.reduce((s, g) => s + g.y, 0) / use.length;
  return { pageX: avgX, pageY: avgY };
}

// ============================================================
// ★ 新方式B：セマンティックコンテナ内 % 方式
// ------------------------------------------------------------
// section / article / main などの「意味のかたまり」を
// クリック地点から一番内側に向かって探し、その“箱の中での相対位置”を
// 縦横の％で記録する。箱の中のレイアウトが組み変わっても、
// 箱そのものの境界は保たれやすいので位置がずれにくい。
// 見出しと違い、ほぼすべてのモダンサイトにこの「箱」が存在する。
// ============================================================

const MU_CONTAINER_TAGS = ['SECTION', 'ARTICLE', 'MAIN', 'ASIDE', 'HEADER', 'FOOTER', 'NAV', 'FORM', 'LI', 'FIGURE'];

// ページ内のセマンティックコンテナを、出現順に番号付きで集める
function muCollectContainers() {
  const sel = MU_CONTAINER_TAGS.map(t => t.toLowerCase()).join(',');
  const list = [];
  for (const el of document.querySelectorAll(sel)) {
    if ((el.id || '').startsWith('mu-') || el.closest('#mu-overlay,#mu-toolbar,#mu-nav')) continue;
    list.push(el);
  }
  return list;
}

// クリックした要素を含む「一番内側のコンテナ」を選び、
// そのコンテナ内での相対位置(%)と、コンテナを後で再発見するための情報を記録する。
function buildContainerAnchor(target, pageX, pageY) {
  let cur = target;
  let container = null;
  while (cur && cur !== document.body && cur !== document.documentElement) {
    if (MU_CONTAINER_TAGS.includes(cur.tagName)) { container = cur; break; }
    cur = cur.parentElement;
  }
  if (!container) return null;
  const rect = container.getBoundingClientRect();
  if (rect.width + rect.height === 0) return null;
  const all = muCollectContainers();
  const sameTag = all.filter(c => c.tagName === container.tagName);
  return {
    tag: container.tagName.toLowerCase(),
    // 同じタグのコンテナの中で何番目か（全体での順番）
    tagIndex: sameTag.indexOf(container),
    tagTotal: sameTag.length,
    // 全コンテナ通しでの順番（タグ構成が変わった時の保険）
    allIndex: all.indexOf(container),
    // コンテナを内容で見分けるための短いテキスト指紋
    sig: muElText(container).slice(0, 60),
    // 箱の中での相対位置（％）
    xPct: rect.width  > 0 ? ((pageX - (rect.left + window.pageXOffset)) / rect.width)  * 100 : 50,
    yPct: rect.height > 0 ? ((pageY - (rect.top  + window.pageYOffset)) / rect.height) * 100 : 50
  };
}

// コンテナアンカーからピンのページ座標を復元する。
// まず同じ種類・同じ順番の箱を探し、ダメなら内容（テキスト指紋）で見分ける。
function findByContainerAnchor(ca) {
  if (!ca || !ca.tag) return null;
  const all = muCollectContainers();
  if (!all.length) return null;
  const sameTag = all.filter(c => c.tagName === ca.tag.toUpperCase());
  let container = null;

  // (1) 同じタグ構成が保たれていれば、同じ順番の箱をそのまま使う
  if (ca.tagTotal != null && sameTag.length === ca.tagTotal && ca.tagIndex < sameTag.length) {
    container = sameTag[ca.tagIndex];
  }
  // (2) 箱の数が変わっていたら、内容（テキスト指紋）が一番似た箱を選ぶ
  if (!container && ca.sig) {
    let best = null, bestScore = 0;
    for (const c of sameTag.length ? sameTag : all) {
      const s = muElText(c).slice(0, 60);
      if (!s) continue;
      let score = 0;
      if (s === ca.sig) score = 100;
      else if (s.startsWith(ca.sig.slice(0, 20)) || ca.sig.startsWith(s.slice(0, 20))) score = 50;
      if (score > bestScore) { bestScore = score; best = c; }
    }
    if (best) container = best;
  }
  // (3) それでもダメなら通し番号で
  if (!container && ca.allIndex != null && ca.allIndex < all.length) {
    container = all[ca.allIndex];
  }
  if (!container) return null;
  const rect = container.getBoundingClientRect();
  if (rect.width + rect.height === 0) return null;
  return {
    pageX: rect.left + window.pageXOffset + (ca.xPct / 100) * rect.width,
    pageY: rect.top  + window.pageYOffset + (ca.yPct / 100) * rect.height
  };
}

// ピンのページ座標を返す（複数の手がかりを順に試す）
function getPinPagePosition(comment) {
  if (comment.element_selector) {
    let anchor;
    try { anchor = JSON.parse(comment.element_selector); } catch (_) { anchor = { sel: comment.element_selector }; }

    // ① 主セレクタ（ID付きなど、決まれば最も速くて正確）
    const el = tryQuerySelector(anchor.sel);
    if (el) {
      const rect = el.getBoundingClientRect();
      if (rect.width + rect.height > 0) {
        const pos = elPos(rect, comment);
        if (pos) return pos;
      }
    }

    // ★② テキストアンカー方式：クリック地点近くの「表示されている文章」を
    //    目印にして位置を復元。DOM構造やクラス名が変わっても文章は残るので強い。
    if (anchor.textAnchors) {
      const pos = findByTextAnchors(anchor.textAnchors);
      if (pos) return pos;
    }

    // ★③ セマンティックコンテナ内%方式：section等の「意味の箱」の中での
    //    相対位置で復元。箱の中のレイアウトが組み変わっても境界は保たれやすい。
    if (anchor.container) {
      const pos = findByContainerAnchor(anchor.container);
      if (pos) return pos;
    }

    // ④ 指紋（fingerprint）方式：要素の中身・属性でページ内を探す。
    //    画面幅が違って並び順や階層がズレても「同じ中身の要素」を見つけられる。
    if (anchor.fp) {
      const found = findByFingerprint(anchor.fp);
      if (found) {
        const rect = found.getBoundingClientRect();
        if (rect.width + rect.height > 0) {
          const pos = elPos(rect, comment);
          if (pos) return pos;
        }
      }
    }

    // ⑤ 外側を1段ずつ省いたセレクタを順番に試す（旧コメント向けの保険）
    for (const s of (anchor.relaxed || [])) {
      const rel = tryQuerySelector(s);
      if (rel) {
        const rect = rel.getBoundingClientRect();
        if (rect.width + rect.height > 0) {
          const pos = elPos(rect, comment);
          if (pos) return pos;
        }
      }
    }

    // ⑥ 見出しアンカー：見出しからの距離を「その見出しの次の見出しまでの区間」の
    //    割合に変換して復元する。px固定ではなく比率にすることで、
    //    レスポンシブで段組みが変わって区間の高さが伸縮しても追従しやすい。
    if (anchor.anchor != null && anchor.anchorDY != null) {
      const h = tryQuerySelector(anchor.anchor);
      if (h) {
        const { w } = overlayDims();
        const hBottom = h.getBoundingClientRect().bottom + window.pageYOffset;
        let pageY;
        if (anchor.anchorRatio != null && anchor.anchorSpan != null) {
          // 保存時の区間の高さと現在の区間の高さの比で距離をスケール
          const curSpan = muHeadingSpan(h);
          const scale = (curSpan > 0 && anchor.anchorSpan > 0) ? curSpan / anchor.anchorSpan : 1;
          pageY = hBottom + anchor.anchorDY * scale;
        } else {
          pageY = hBottom + anchor.anchorDY;
        }
        return { pageX: _bodyXToDoc((comment.x_percent / 100) * w), pageY };
      }
    }
  }

  // ⑦ ページ % フォールバック
  const { w, h } = overlayDims();
  return {
    pageX: _bodyXToDoc((comment.x_percent / 100) * w),
    pageY: _bodyYToDoc((comment.y_percent / 100) * h)
  };
}

// body-local x/y を getPinPagePosition の出力形式（ドキュメント座標）に変換
function _bodyXToDoc(bx) {
  const vp = getVpSimParams();
  return vp ? bx * vp.scale + vp.tx : bx;
}
function _bodyYToDoc(by) {
  const vp = getVpSimParams();
  return vp ? by * vp.scale + vp.ty : by;
}

// 見出しから「次の見出しまで」の縦の距離を返す（区間の高さ）
function muHeadingSpan(h) {
  const all = Array.from(document.querySelectorAll('h1,h2,h3,h4,h5,h6'));
  const hTop = h.getBoundingClientRect().top + window.pageYOffset;
  let nextTop = Infinity;
  for (const other of all) {
    if (other === h) continue;
    const t = other.getBoundingClientRect().top + window.pageYOffset;
    if (t > hTop && t < nextTop) nextTop = t;
  }
  if (nextTop === Infinity) {
    const { h: pageH } = overlayDims();
    nextTop = pageH;
  }
  return nextTop - hTop;
}

function elPos(rect, comment) {
  const xp = comment.el_x_pct ?? 0;
  const yp = comment.el_y_pct ?? 0;
  // 旧バージョンで body-local 座標を誤保存した場合、値が [-200, 300] を大きく外れる
  if (xp < -200 || xp > 300 || yp < -200 || yp > 300) return null;
  return {
    pageX: rect.left + window.pageXOffset + (xp / 100) * rect.width,
    pageY: rect.top  + window.pageYOffset + (yp / 100) * rect.height
  };
}

function tryQuerySelector(sel) {
  if (!sel) return null;
  try { return document.querySelector(sel); } catch (_) { return null; }
}

// セレクタを段階的に緩めた候補リストを返す（外側から1段ずつ削る）
function getRelaxedSelectors(selector) {
  const parts = selector.split(' > ');
  const result = [];
  for (let skip = 1; skip < parts.length - 1; skip++) {
    result.push(parts.slice(skip).join(' > '));
  }
  return result;
}

// クリック位置より上にある最近傍の見出し要素を返す
function findNearestHeading(pageY) {
  let nearest = null, nearestBottom = -Infinity;
  for (const h of document.querySelectorAll('h1,h2,h3,h4,h5,h6')) {
    const bottom = h.getBoundingClientRect().bottom + window.pageYOffset;
    if (bottom <= pageY && bottom > nearestBottom) { nearestBottom = bottom; nearest = h; }
  }
  return nearest;
}

// サイト固有の fixed ヘッダーを検出して 48px 押し下げる

function pushRightFixedForPanel() {
  MU_SITE_FIXED_PANEL = [];
  const PANEL_W = 210;
  const scan = (el, depth) => {
    if (depth > 4 || (el.id || '').startsWith('mu-')) return;
    const s = getComputedStyle(el);
    if (s.position === 'fixed' && parseFloat(s.zIndex || 0) < 2147483644) {
      const right = parseFloat(s.right);
      if (!isNaN(right) && right >= 0 && right < 10) {
        MU_SITE_FIXED_PANEL.push({ el, origRight: el.style.right });
        el.style.setProperty('right', (right + PANEL_W) + 'px', 'important');
        return;
      }
    }
    [...el.children].forEach(c => scan(c, depth + 1));
  };
  [...document.body.children].forEach(el => scan(el, 0));
}

function restoreRightFixedForPanel() {
  MU_SITE_FIXED_PANEL.forEach(({ el, origRight }) => { el.style.right = origRight; });
  MU_SITE_FIXED_PANEL = [];
}

// 画面幅変更時にすべてのピン位置を再計算
function repositionPins() {
  MU.comments.forEach(comment => {
    const pin = MU.pinElements[comment.id];
    if (!pin) return;
    const doc = getPinPagePosition(comment);
    const { pageX, pageY } = vpToBodyLocal(doc.pageX, doc.pageY);
    pin.style.left = pageX + 'px';
    pin.style.top  = pageY + 'px';
  });
}

function buildUI() {
  ['mu-toolbar', 'mu-overlay'].forEach(id => document.getElementById(id)?.remove());
  buildTopUI();
  const overlay = document.createElement('div');
  overlay.id = 'mu-overlay';
  document.body.appendChild(overlay);
  syncOverlaySize();
  window.addEventListener('resize', syncOverlaySize);
  overlay.addEventListener('click', onOverlayClick);
  if (MU.panelOpen) {
    // パネル幅の確保は applyViewportSim（availW = innerWidth - 210）が担う。
    // ここで applyPanelOffset を呼ぶと vp-sim 有効化前のため padding が残り崩れる。
    buildPanel();
  }
}

function buildTopUI() {
  const toolbar = document.createElement('div');
  toolbar.id = 'mu-toolbar';
  toolbar.className = 'mu-toolbar-top';
  toolbar.innerHTML = `
    <div class="mu-left">
      <div class="mu-logo-wrap">
        <span class="mu-logo">Mark Upper</span>
        <span class="mu-version">v${chrome.runtime.getManifest().version}</span>
      </div>
      <div class="mu-seg">
        <button class="mu-seg-btn${MU.device === 'pc' ? ' mu-seg-on' : ''}" id="mu-dev-pc">PC</button>
        <button class="mu-seg-btn${MU.device === 'mobile' ? ' mu-seg-on' : ''}" id="mu-dev-mobile">Mobile</button>
      </div>
      <button class="mu-pill mu-pill-icon" id="mu-theme-btn" title="${MU.theme === 'dark' ? 'ライトモードへ' : 'ダークモードへ'}">${MU.theme === 'dark' ? '☀' : '🌙'}</button>
    </div>
    <div class="mu-right">
      <button class="mu-pill" id="mu-user-btn">
        <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="4.5" r="2.5" stroke="currentColor" stroke-width="1.5"/><path d="M2 12c0-2.76 2.24-5 5-5s5 2.24 5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
        <span id="mu-user-label">${escHtml(MU.userName || '名前を設定')}</span>
      </button>
      <button class="mu-pill${MU.commenting ? ' mu-pill-on' : ''}" id="mu-comment-btn">
        <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><path d="M9.5 1.5L12.5 4.5L5 12H2V9L9.5 1.5Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
        <span class="mu-btn-label">コメント</span>
      </button>
      <button class="mu-pill" id="mu-share-btn">
        <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><circle cx="11" cy="2.5" r="1.5" stroke="currentColor" stroke-width="1.3"/><circle cx="11" cy="11.5" r="1.5" stroke="currentColor" stroke-width="1.3"/><circle cx="3" cy="7" r="1.5" stroke="currentColor" stroke-width="1.3"/><line x1="4.3" y1="6.2" x2="9.7" y2="3.3" stroke="currentColor" stroke-width="1.3"/><line x1="4.3" y1="7.8" x2="9.7" y2="10.7" stroke="currentColor" stroke-width="1.3"/></svg>
        <span class="mu-btn-label">共有</span>
      </button>
      <button class="mu-pill" id="mu-sites-btn">
        <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><rect x="1" y="1" width="5" height="5" rx="1" stroke="currentColor" stroke-width="1.3"/><rect x="8" y="1" width="5" height="5" rx="1" stroke="currentColor" stroke-width="1.3"/><rect x="1" y="8" width="5" height="5" rx="1" stroke="currentColor" stroke-width="1.3"/><rect x="8" y="8" width="5" height="5" rx="1" stroke="currentColor" stroke-width="1.3"/></svg>
        <span class="mu-btn-label">サイト</span>
      </button>
      <button class="mu-pill${MU.panelOpen ? ' mu-pill-on' : ''}" id="mu-panel-btn">
        <svg width="13" height="13" viewBox="0 0 14 14" fill="none"><line x1="1" y1="3.5" x2="13" y2="3.5" stroke="currentColor" stroke-width="1.5"/><line x1="1" y1="7" x2="13" y2="7" stroke="currentColor" stroke-width="1.5"/><line x1="1" y1="10.5" x2="13" y2="10.5" stroke="currentColor" stroke-width="1.5"/></svg>
        <span class="mu-btn-label">一覧</span>
      </button>
      <button class="mu-pill mu-pill-close" id="mu-off-btn">✕</button>
    </div>`;
  document.documentElement.appendChild(toolbar);
  bindCommonButtons();
}

function toggleCommentMode() {
  MU.commenting = !MU.commenting;
  const overlay = document.getElementById('mu-overlay');
  const btn = document.getElementById('mu-comment-btn');
  if (MU.commenting) {
    overlay?.classList.add('mu-cross');
    btn?.classList.add('mu-pill-on');
  } else {
    overlay?.classList.remove('mu-cross');
    btn?.classList.remove('mu-pill-on');
    closePopover();
  }
}

async function shareSession() {
  if (!MU.sessionId) return;
  const url = `https://wtrnishi-debug.github.io/mark-upper-site/app/?s=${MU.sessionId}`;
  try {
    await navigator.clipboard.writeText(url);
    showCursorAlert(window.pageXOffset + window.innerWidth / 2, window.pageYOffset + 110, '🔗 URLをコピーしました');
  } catch (_) {
    window.prompt('URLをコピーしてください:', url);
  }
}

function applyPanelOffset() {
  // vp-sim 中は applyViewportSim がパネル幅(210px)を確保済み。
  // ここで html に padding を足すと二重にずれてページが崩れるため何もしない。
  if (getVpSimParams()) return;
  if (MU_ORIG_MR !== null) return;
  const html = document.documentElement;
  MU_ORIG_MR = {
    pr: { v: html.style.getPropertyValue('padding-right'), p: html.style.getPropertyPriority('padding-right') },
    bs: { v: html.style.getPropertyValue('box-sizing'),   p: html.style.getPropertyPriority('box-sizing') },
  };
  html.style.setProperty('padding-right', '210px', 'important');
  html.style.setProperty('box-sizing', 'border-box', 'important');
  pushRightFixedForPanel();
}

function removePanelOffset() {
  if (!MU_ORIG_MR) return;
  const html = document.documentElement;
  html.style.removeProperty('padding-right');
  html.style.removeProperty('box-sizing');
  if (MU_ORIG_MR.pr.v) html.style.setProperty('padding-right', MU_ORIG_MR.pr.v, MU_ORIG_MR.pr.p);
  if (MU_ORIG_MR.bs.v) html.style.setProperty('box-sizing',   MU_ORIG_MR.bs.v, MU_ORIG_MR.bs.p);
  MU_ORIG_MR = null;
  restoreRightFixedForPanel();
}

function togglePanel() {
  MU.panelOpen = !MU.panelOpen;
  const btn = document.getElementById('mu-panel-btn');
  if (MU.panelOpen) {
    btn?.classList.add('mu-pill-on');
    buildPanel();
    updatePanel();
    applyPanelOffset();
  } else {
    btn?.classList.remove('mu-pill-on');
    document.getElementById('mu-panel')?.remove();
    removePanelOffset();
  }
  applyViewportSim();
}

function buildPanel() {
  document.getElementById('mu-panel')?.remove();
  const domain = location.hostname;
  const panel = document.createElement('div');
  panel.id = 'mu-panel';
  panel.innerHTML = `
    <div class="mu-panel-hdr">
      <div class="mu-panel-hdr-left">
        <span class="mu-panel-domain" title="${escHtml(domain)}">${escHtml(domain)}</span>
        <span class="mu-panel-title">コメント一覧</span>
      </div>
      <button class="mu-panel-close" id="mu-panel-close">✕</button>
    </div>
    <div class="mu-panel-body" id="mu-panel-body">
      <div class="mu-panel-loading">読み込み中…</div>
    </div>
    <div class="mu-panel-footer">
      <button class="mu-panel-clr-btn" id="mu-panel-clr-btn">🗑 コメントを全削除</button>
    </div>`;
  document.documentElement.appendChild(panel);
  document.getElementById('mu-panel-close').addEventListener('click', togglePanel);
  document.getElementById('mu-panel-clr-btn').addEventListener('click', clearSiteComments);
}

async function updatePanel() {
  const body = document.getElementById('mu-panel-body');
  if (!body || !MU.sessionId) return;
  const all = await sb_getAllSessionComments(MU.sessionId);
  if (!all || !all.length) {
    body.innerHTML = '<div class="mu-panel-empty">コメントはまだありません</div>';
    return;
  }
  const stLabel = { open: '未対応', fixed: '対応済', verified: '確認完了', rejected: '差し戻し' };
  const pages = new Map();
  all.forEach(c => {
    if (!pages.has(c.page_url)) pages.set(c.page_url, []);
    pages.get(c.page_url).push(c);
  });
  let n = 0;
  let html = '';
  pages.forEach((comments, url) => {
    let shortUrl;
    try {
      const u = new URL(url);
      const path = u.pathname.replace(/^\//, '').replace(/\/$/, '');
      shortUrl = path || u.hostname;
    } catch (_) {
      shortUrl = url.replace(/^https?:\/\//, '').replace(/\/$/, '');
    }
    if (shortUrl.length > 28) shortUrl = '…' + shortUrl.slice(-26);
    const isCurrent = url === MU.pageUrl;
    html += `<div class="mu-pg">
      <div class="mu-pg-hdr">
        <span class="mu-pg-url" title="${escHtml(url)}">${escHtml(shortUrl)}</span>
        ${isCurrent ? '<span class="mu-pg-cur">現在</span>' : ''}
      </div>`;
    comments.forEach(c => {
      n++;
      const unread = !MU_READ_IDS.has(c.id);
      html += `<div class="mu-pi${unread ? ' mu-pi-unread' : ''}" data-id="${c.id}" data-url="${escHtml(c.page_url)}">
        <div class="mu-pi-num mu-pin-${c.status}">${n}</div>
        <div class="mu-pi-body">
          <div class="mu-pi-meta">
            <span class="mu-pi-author">${escHtml(c.author)}</span>
            <span class="mu-pi-bp">${c.breakpoint === 'mobile' ? 'SP' : 'PC'}</span>
            <span class="mu-pi-st mu-pi-st-${c.status}">${stLabel[c.status] || c.status}</span>
            <span class="mu-pi-date">${formatDate(c.created_at)}</span>
          </div>
          <div class="mu-pi-text">${escHtml(c.text.length > 44 ? c.text.slice(0, 44) + '…' : c.text)}</div>
        </div>
      </div>`;
    });
    html += '</div>';
  });
  body.innerHTML = html;
  body.querySelectorAll('.mu-pi').forEach(el => {
    el.addEventListener('click', () => {
      const id = el.dataset.id;
      const url = el.dataset.url;
      const comment = url === MU.pageUrl
        ? MU.comments.find(c => c.id === id)
        : all.find(c => c.id === id);
      if (url === MU.pageUrl) {
        if (comment) {
          const { pageY } = getPinPagePosition(comment);
          window.scrollTo({ top: Math.max(0, pageY - window.innerHeight / 2 + 20), behavior: 'smooth' });
        }
      } else {
        chrome.storage.local.set({ mu_jump_to: id });
        window.location.href = url;
      }
    });
  });
}

function openSitesModal() {
  if (document.getElementById('mu-sites-modal')) return;
  const modal = document.createElement('div');
  modal.id = 'mu-sites-modal';
  modal.innerHTML = `
    <div class="mu-modal-box">
      <div class="mu-modal-hdr">
        <span class="mu-modal-title">コメントサイト一覧</span>
        <button class="mu-modal-close" id="mu-modal-close">✕</button>
      </div>
      <div class="mu-modal-body" id="mu-modal-body">
        <div class="mu-panel-loading">読み込み中…</div>
      </div>
    </div>`;
  document.documentElement.appendChild(modal);
  document.getElementById('mu-modal-close').addEventListener('click', closeSitesModal);
  modal.addEventListener('click', e => { if (e.target === modal) closeSitesModal(); });
  loadSitesModal();
}

function closeSitesModal() {
  document.getElementById('mu-sites-modal')?.remove();
}

async function loadSitesModal() {
  const body = document.getElementById('mu-modal-body');
  if (!body) return;
  if (!MU.userName) {
    body.innerHTML = '<div class="mu-panel-empty">名前を設定してください</div>';
    return;
  }
  const sites = await sb_getMySites(MU.userName);
  if (!sites.length) {
    body.innerHTML = '<div class="mu-panel-empty">コメントはまだありません</div>';
    return;
  }
  const stLabel = { open: '未対応', fixed: '対応済', verified: '確認完了', rejected: '差し戻し' };
  const stCls   = { open: 'mu-st-open', fixed: 'mu-st-fixed', verified: 'mu-st-verified', rejected: 'mu-st-rejected' };
  body.innerHTML = '<div class="mu-modal-grid">' + sites.map(s => {
    const url      = 'https://' + s.domain;
    const favUrl   = 'https://www.google.com/s2/favicons?domain=' + s.domain + '&sz=32';
    const badges   = ['open', 'fixed', 'verified', 'rejected'].map(k =>
      `<span class="mu-st-badge ${stCls[k]}${!s.status[k] ? ' mu-st-zero' : ''}">${stLabel[k]} ${s.status[k] || 0}</span>`
    ).join('');
    // サムネはサイトの OGP 画像（og:image）。サイト自身のドメイン画像なので
    // 外部スクショサービスのようにブロッカーで遮られない。
    // モーダルはホストページ内に挿入されCSP(img-src)に縛られるため、
    // background 経由で HTML取得→og:image抽出→dataURL化して表示する（muLoadOgp）。
    // og:image が無い／取得失敗時はファビコン表示にフォールバック。
    return `<a class="mu-modal-card" href="${escHtml(url)}" target="_blank" rel="noopener">
      <div class="mu-modal-thumb">
        <img class="mu-modal-shot" data-ogp="${escHtml(url)}" alt="">
        <div class="mu-modal-thumb-fb" style="display:none">
          <img class="mu-modal-fav-lg" data-fav="${escHtml(favUrl)}" alt="">
          <span class="mu-modal-domain-sm">${escHtml(s.domain)}</span>
        </div>
      </div>
      <div class="mu-modal-card-body">
        <div class="mu-modal-card-row">
          <img class="mu-modal-fav-sm" data-fav="${escHtml(favUrl)}" alt="">
          <span class="mu-modal-domain">${escHtml(s.domain)}</span>
        </div>
        <span class="mu-modal-url">${escHtml(url)}</span>
        <div class="mu-modal-badges">${badges}</div>
      </div>
    </a>`;
  }).join('') + '</div>';
  // サムネ（OGP）もファビコンも CSP 回避のため background 経由で読み込む
  body.querySelectorAll('.mu-modal-shot').forEach(muLoadOgp);
  body.querySelectorAll('.mu-modal-fav-lg, .mu-modal-fav-sm').forEach(muLoadFavicon);
}

// サムネ／ファビコンの dataURL キャッシュ。モーダルを開くたびの再取得を避け、
// 2回目以降を即表示にする。メモリ＋chrome.storage.local（TTL付き）。
const MU_IMG_MEM = {};
const MU_IMG_TTL = 7 * 24 * 3600 * 1000; // 7日
async function muCacheGet(key) {
  if (key in MU_IMG_MEM) return { hit: true, val: MU_IMG_MEM[key] };
  try {
    const { mu_img_cache } = await chrome.storage.local.get('mu_img_cache');
    const c = mu_img_cache?.[key];
    if (c && (Date.now() - c.ts) < MU_IMG_TTL) { MU_IMG_MEM[key] = c.val; return { hit: true, val: c.val }; }
  } catch (_) {}
  return { hit: false };
}
async function muCacheSet(key, val) {
  MU_IMG_MEM[key] = val;
  try {
    const { mu_img_cache } = await chrome.storage.local.get('mu_img_cache');
    const c = mu_img_cache || {};
    const now = Date.now();
    for (const k in c) { if (now - c[k].ts > MU_IMG_TTL) delete c[k]; } // 期限切れを掃除
    c[key] = { val, ts: now };
    await chrome.storage.local.set({ mu_img_cache: c });
  } catch (_) {}
}

// ファビコンを background 経由で取得し dataURL として表示（CSP回避）。失敗時は非表示。
async function muLoadFavicon(img) {
  const src = img.dataset.fav;
  if (!src) return;
  // CSS 側が display:block!important のため、インラインも important で打ち消す
  const hide = () => { img.style.setProperty('display', 'none', 'important'); };
  const cached = await muCacheGet('fav:' + src);
  if (cached.hit) { if (cached.val) img.src = cached.val; else hide(); return; }
  img.addEventListener('error', hide, { once: true });
  try {
    const res = await chrome.runtime.sendMessage({ type: 'FETCH_IMAGE', url: src });
    if (res?.ok && res.dataUrl) { img.src = res.dataUrl; muCacheSet('fav:' + src, res.dataUrl); }
    else { hide(); muCacheSet('fav:' + src, null); }
  } catch (_) {
    hide();
  }
}

// サムネ＝サイトの OGP 画像、タイトル＝ページの <title>（ブラウザタブと同じ）を background 経由で取得。
// 未キャッシュ時はまずファビコンを即表示（プレースホルダ）、OGPが届いたら差し替える。
// og:image が無い／取得失敗時はファビコン表示のまま。結果(画像+タイトル)はキャッシュして次回以降は即表示。
async function muLoadOgp(img) {
  const url = img.dataset.ogp;
  if (!url) return;
  const fb = img.nextElementSibling;
  const card = img.closest('.mu-modal-card');
  const titleEl = card ? card.querySelector('.mu-modal-domain') : null;
  const setTitle = (t) => { if (titleEl && t) titleEl.textContent = t; };
  const showFb  = () => { img.style.setProperty('display', 'none', 'important'); if (fb) fb.style.setProperty('display', 'flex', 'important'); };
  const showImg = (dataUrl) => { if (fb) fb.style.setProperty('display', 'none', 'important'); img.style.setProperty('display', 'block', 'important'); img.src = dataUrl; };

  const cached = await muCacheGet('ogp2:' + url);
  if (cached.hit) {
    const v = cached.val || {};
    setTitle(v.title);
    if (v.img) showImg(v.img); else showFb();
    return;
  }

  // 未キャッシュ: ファビコンを先に出してOGP取得を待つ（初回のブランク時間をなくす）
  showFb();
  img.addEventListener('error', showFb, { once: true });
  try {
    const res = await chrome.runtime.sendMessage({ type: 'FETCH_OGP', url });
    if (res?.ok) {
      setTitle(res.title);
      if (res.dataUrl) showImg(res.dataUrl); else showFb();
      muCacheSet('ogp2:' + url, { img: res.dataUrl || null, title: res.title || null });
    } else {
      showFb();
      muCacheSet('ogp2:' + url, { img: null, title: null });
    }
  } catch (_) {
    showFb();
  }
}

function bindCommonButtons() {
  document.getElementById('mu-off-btn').addEventListener('click', deactivate);
  document.getElementById('mu-user-btn').addEventListener('click', openNameEditor);
  document.getElementById('mu-comment-btn').addEventListener('click', toggleCommentMode);
  document.getElementById('mu-share-btn').addEventListener('click', shareSession);
  document.getElementById('mu-panel-btn').addEventListener('click', togglePanel);
  document.getElementById('mu-dev-pc').addEventListener('click', () => setDevice('pc'));
  document.getElementById('mu-dev-mobile').addEventListener('click', () => setDevice('mobile'));
  document.getElementById('mu-theme-btn')?.addEventListener('click', toggleTheme);
  document.getElementById('mu-sites-btn')?.addEventListener('click', openSitesModal);
}

function openNameEditor() {
  if (document.getElementById('mu-name-panel')) return;
  const btn = document.getElementById('mu-user-btn');
  if (!btn) return;
  const btnRect = btn.getBoundingClientRect();
  const panel = document.createElement('div');
  panel.id = 'mu-name-panel';
  panel.className = 'mu-name-panel';
  panel.style.cssText = `position:fixed!important;top:${btnRect.bottom + 6}px!important;right:${window.innerWidth - btnRect.right}px!important`;
  panel.innerHTML = `
    <input type="text" id="mu-name-inp" class="mu-name-inp"
      value="${escHtml(MU.userName)}" placeholder="使用する名前を入力" maxlength="20">
    <button class="mu-btn mu-sub" id="mu-name-ok">確定</button>`;
  document.documentElement.appendChild(panel);
  const inp = document.getElementById('mu-name-inp');
  inp.focus();
  if (MU.userName) inp.select();
  const commit = () => {
    const name = inp.value.trim();
    if (name && name !== MU.userName) {
      MU.userName = name;
      chrome.storage.local.set({ mu_username: name });
      sb_addMember(name);
      const label = document.getElementById('mu-user-label');
      if (label) label.textContent = name;
    }
    panel.remove();
  };
  document.getElementById('mu-name-ok').addEventListener('click', commit);
  inp.addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault(); commit(); }
    if (e.key === 'Escape') { inp.value = MU.userName; commit(); }
  });
  inp.addEventListener('blur', () => {
    setTimeout(() => { if (document.getElementById('mu-name-panel')) commit(); }, 150);
  });
}

function onOverlayClick(e) {
  if (!MU.commenting) return;
  if (e.target !== document.getElementById('mu-overlay')) return;
  if (MU_DRAG) return; // ドラッグ操作中・直後のクリックは無視
  if (document.getElementById('mu-popover')) {
    if (!isFormDirty()) closePopover();
    return;
  }
  const { w, h } = overlayDims();
  const vp0 = getVpSimParams();
  // docX/docY: ドキュメント座標（anchor 保存用）
  const docX = e.clientX + window.pageXOffset;
  const docY = e.clientY + window.pageYOffset;
  // pageX/pageY: overlay-local 座標（% 計算・ポップオーバー表示用）
  let pageX, pageY;
  if (vp0) {
    pageX = (docX - vp0.tx) / vp0.scale;
    pageY = (docY - vp0.ty) / vp0.scale;
  } else {
    const oRect = e.currentTarget.getBoundingClientRect();
    pageX = e.clientX - oRect.left;
    pageY = e.clientY - oRect.top;
  }

  if (!MU.userName) {
    showCursorAlert(pageX, pageY, '👤 先に名前を入力してください');
    openNameEditor();
    return;
  }
  const xPct = (pageX / w) * 100;
  const yPct = (pageY / h) * 100;

  // オーバーレイを一時的に無効化して真下の要素を取得
  const overlay = document.getElementById('mu-overlay');
  overlay.style.pointerEvents = 'none';
  const target = document.elementFromPoint(e.clientX, e.clientY);
  overlay.style.pointerEvents = '';

  // anchor 保存にはドキュメント座標を使う（getBoundingClientRect+scroll と同じ空間）
  const elementData = buildElementData(target, docX, docY);

  openCommentForm(xPct, yPct, pageX, pageY, elementData);
}

// あるページ座標（pageX,pageY）と、その真下の要素（target）から、
// ピンの位置を保存・復元するためのアンカー情報一式を組み立てる。
// 新規コメント作成時にもピンのドラッグ移動時にも共通で使う。
// docX/docY はドキュメント座標（clientX + pageXOffset）を受け取る。
// getBoundingClientRect()+scroll と同じ空間なので内部計算がすべて整合する。
function buildElementData(target, docX, docY) {
  if (!target || target === document.body || target === document.documentElement) return null;
  const rect = target.getBoundingClientRect();
  const sel = getCssSelector(target);
  const anchorData = { sel, fp: buildFingerprint(target), relaxed: getRelaxedSelectors(sel), vw: window.innerWidth, vh: window.innerHeight };
  const textAnchors = buildTextAnchors(docX, docY);
  if (textAnchors) anchorData.textAnchors = textAnchors;
  const container = buildContainerAnchor(target, docX, docY);
  if (container) anchorData.container = container;
  const heading = findNearestHeading(docY);
  if (heading) {
    anchorData.anchor = getCssSelector(heading);
    anchorData.anchorDY = Math.round(docY - (heading.getBoundingClientRect().bottom + window.pageYOffset));
    anchorData.anchorSpan = Math.round(muHeadingSpan(heading));
    anchorData.anchorRatio = anchorData.anchorSpan > 0 ? anchorData.anchorDY / anchorData.anchorSpan : 0;
  }
  return {
    element_selector: JSON.stringify(anchorData),
    el_x_pct: rect.width  > 0 ? ((docX - (rect.left + window.pageXOffset)) / rect.width)  * 100 : 0,
    el_y_pct: rect.height > 0 ? ((docY - (rect.top  + window.pageYOffset)) / rect.height) * 100 : 0
  };
}

// ポップオーバーをページ座標に表示
function showPopover(pageX, pageY, html) {
  document.getElementById('mu-popover')?.remove();
  const overlay = document.getElementById('mu-overlay');
  const vp = getVpSimParams();

  const pop = document.createElement('div');
  pop.id = 'mu-popover';
  pop.className = 'mu-pop';
  pop.innerHTML = html;
  overlay.classList.add('mu-pop-open');

  const OFFSET = 16;

  if (vp) {
    // vp sim 中は html に fixed で追加して body のスケールの影響を受けないようにする
    pop.classList.add('mu-pop-vp');
    document.documentElement.appendChild(pop);
    const { x: sx, y: sy } = vpToScreen(pageX, pageY);
    pop.style.left = (sx + OFFSET) + 'px';
    pop.style.top  = (sy + OFFSET) + 'px';
    requestAnimationFrame(() => {
      const pw = pop.offsetWidth, ph = pop.offsetHeight;
      const { x: sxr, y: syr } = vpToScreen(pageX, pageY);
      let left = sxr + OFFSET, top = syr + OFFSET;
      if (left + pw > window.innerWidth  - 8) left = sxr - pw - OFFSET;
      if (top  + ph > window.innerHeight - 8) top  = syr - ph - OFFSET;
      pop.style.left = Math.max(4,  left) + 'px';
      pop.style.top  = Math.max(64, top)  + 'px';
    });
  } else {
    overlay.appendChild(pop);
    pop.style.left = (pageX + OFFSET) + 'px';
    pop.style.top  = (pageY + OFFSET) + 'px';
    requestAnimationFrame(() => {
      const pw = pop.offsetWidth, ph = pop.offsetHeight;
      const vw = window.innerWidth, vh = window.innerHeight;
      const sl = window.pageXOffset, st = window.pageYOffset;
      let left = pageX + OFFSET, top = pageY + OFFSET;
      if (left + pw - sl > vw - 8) left = pageX - pw - OFFSET;
      if (top  + ph - st > vh - 8) top  = pageY - ph - OFFSET;
      const minLeft = Math.max(sl + 4, left);
      pop.style.left = minLeft + 'px';
      pop.style.top  = Math.max(st + 64, top) + 'px';
    });
  }

  pop.addEventListener('mouseenter', clearHoverTimer);
  pop.addEventListener('mouseleave', startHoverClose);
  return pop;
}

function showCursorAlert(pageX, pageY, message) {
  document.getElementById('mu-cursor-alert')?.remove();
  const overlay = document.getElementById('mu-overlay');
  if (!overlay) return;
  const el = document.createElement('div');
  el.id = 'mu-cursor-alert';
  el.className = 'mu-cursor-alert';
  el.textContent = message;
  const vp = getVpSimParams();
  if (vp) {
    el.classList.add('mu-alert-vp');
    document.documentElement.appendChild(el);
    const { x: sx, y: sy } = vpToScreen(pageX, pageY);
    el.style.left = (sx + 14) + 'px';
    el.style.top  = Math.max(64, sy - 38) + 'px';
  } else {
    overlay.appendChild(el);
    el.style.left = (pageX + 14) + 'px';
    el.style.top  = Math.max(window.pageYOffset + 64, pageY - 38) + 'px';
  }
  setTimeout(() => el.remove(), 2500);
}

function closePopover() {
  document.getElementById('mu-popover')?.remove();
  document.getElementById('mu-overlay')?.classList.remove('mu-pop-open');
  Object.values(MU.pinElements).forEach(p => p.classList.remove('mu-sel'));
  MU.selectedId = null;
  MU_OBJECT_URLS.forEach(u => URL.revokeObjectURL(u));
  MU_OBJECT_URLS = [];
}

function clearHoverTimer() { clearTimeout(MU_HOVER_TIMER); }

// フォームに未送信の内容（テキスト or 添付 or ファイル選択中）があるか確認
function isFormDirty() {
  if (MU_FILE_OPEN) return true;
  const hasText = !!(document.getElementById('mu-new-text')?.value.trim() ||
                     document.getElementById('mu-reply-text')?.value.trim());
  const hasFile = (document.getElementById('mu-new-prev')?.children.length > 0) ||
                  (document.getElementById('mu-reply-prev')?.children.length > 0);
  return hasText || hasFile;
}

// ファイル選択ダイアログが開いている間は閉じないようにする
function lockForFilePicker(inputEl) {
  MU_FILE_OPEN = true;
  const release = () => setTimeout(() => { MU_FILE_OPEN = false; }, 300);
  inputEl.addEventListener('change', () => { MU_FILE_OPEN = false; }, { once: true });
  window.addEventListener('focus', release, { once: true });
}

function startHoverClose() {
  if (isFormDirty()) return;
  MU_HOVER_TIMER = setTimeout(() => closePopover(), 200);
}

// 新規コメント入力フォームをポップオーバーで表示
function openCommentForm(xPct, yPct, pageX, pageY, elementData) {
  showPopover(pageX, pageY, `
    <div class="mu-pop-hdr">
      <span class="mu-pop-ttl">新しいコメント</span>
      <button class="mu-pop-x" id="mu-pop-x">✕</button>
    </div>
    <div class="mu-pop-body">
      <textarea class="mu-ta" id="mu-new-text" placeholder="コメントを入力… @名前でメンション"></textarea>
      <div class="mu-dd" id="mu-new-dd"></div>
      <div class="mu-prev" id="mu-new-prev"></div>
      <div id="mu-send-err" class="mu-err"></div>
      <div class="mu-fa">
        <button class="mu-btn mu-img-btn" id="mu-new-attach-btn">📎 添付</button>
        <input type="file" id="mu-new-img" style="display:none">
        <button class="mu-btn mu-img-btn" id="mu-new-ss-btn">スクショ</button>
        <button class="mu-btn mu-sub" id="mu-new-submit">送信</button>
      </div>
    </div>`);

  // 新規コメントフォームはホバーで閉じない
  const pop = document.getElementById('mu-popover');
  pop.removeEventListener('mouseleave', startHoverClose);

  document.getElementById('mu-pop-x').addEventListener('click', closePopover);
  document.getElementById('mu-new-text').focus({ preventScroll: true });

  let members = [], pendingImages = [];
  sb_getMembers().then(m => { members = m || []; });

  setupMention('mu-new-text', 'mu-new-dd', () => members, (name) => {
    const ta = document.getElementById('mu-new-text');
    const at = ta.value.lastIndexOf('@');
    ta.value = ta.value.slice(0, at) + '@' + name + ' ';
    document.getElementById('mu-new-dd').style.display = 'none';
    ta.focus();
  });

  const newImgInp = document.getElementById('mu-new-img');
  document.getElementById('mu-new-attach-btn').addEventListener('click', () => {
    lockForFilePicker(newImgInp);
    newImgInp.click();
  });
  document.getElementById('mu-new-ss-btn').addEventListener('click', async () => {
    const btn = document.getElementById('mu-new-ss-btn');
    btn.disabled = true;
    btn.textContent = '撮影中…';
    const err = document.getElementById('mu-send-err');
    try {
      const ss = await captureScreenshot();
      pendingImages.push(ss);
      const previewBlob = await (await fetch(ss.preview)).blob();
      const previewFile = new File([previewBlob], 'screenshot.jpg', { type: 'image/jpeg' });
      addImgThumb('mu-new-prev', previewFile, () => { const i = pendingImages.indexOf(ss); if (i !== -1) pendingImages.splice(i, 1); });
      if (err) err.textContent = '';
    } catch (e) {
      if (err) err.textContent = 'スクリーンショットの取得に失敗しました。';
    } finally {
      btn.disabled = false;
      btn.textContent = 'スクショ';
    }
  });
  newImgInp.addEventListener('change', (e) => {
    MU_FILE_OPEN = false;
    const file = e.target.files[0];
    if (!file) return;
    const err = document.getElementById('mu-send-err');
    if (file.size > MU_MAX_FILE) {
      if (err) err.textContent = `ファイルが10MBを超えています（${(file.size/1024/1024).toFixed(1)}MB）`;
      e.target.value = '';
      return;
    }
    if (err) err.textContent = '';
    pendingImages.push(file);
    addImgThumb('mu-new-prev', file, () => { const i = pendingImages.indexOf(file); if (i !== -1) pendingImages.splice(i, 1); });
  });

  document.getElementById('mu-new-submit').addEventListener('click', async () => {
    const text = document.getElementById('mu-new-text').value.trim();
    if (!text) return;
    const btn = document.getElementById('mu-new-submit');
    btn.disabled = true;
    btn.textContent = '送信中…';

    const result = await sb_addComment({
      session_id: MU.sessionId,
      page_url:   MU.pageUrl,
      breakpoint: MU.device,
      x_percent: xPct, y_percent: yPct,
      ...(elementData || {}),
      text, author: MU.userName, assignee: extractMention(text),
      status: 'open', image_paths: []
    });

    if (!result || !result[0]) {
      btn.disabled = false; btn.textContent = '送信';
      const err = document.getElementById('mu-send-err');
      if (err) err.textContent = '送信に失敗しました。再度お試しください。';
      return;
    }
    const newComment = result[0];

    if (pendingImages.length > 0) {
      try {
        const paths = [];
        for (const item of pendingImages) {
          if (item?.type === 'screenshot') {
            const r = await chrome.runtime.sendMessage({ type: 'UPLOAD_SCREENSHOT', tempId: item.tempId, commentId: newComment.id });
            if (!r?.ok) throw new Error(r?.error || 'スクリーンショットのアップロード失敗');
            paths.push(r.url);
          } else {
            paths.push(await sb_uploadImage(item, newComment.id));
          }
        }
        await sb_updateImagePaths(newComment.id, paths);
        newComment.image_paths = paths;
      } catch (e) {
        console.error('[Mark Upper] 画像アップロード失敗:', e);
        const err = document.getElementById('mu-send-err');
        if (err) err.textContent = `画像のアップロードに失敗しました: ${e.message}`;
        btn.disabled = false; btn.textContent = '送信';
        return;
      }
    }

    MU.comments.push(newComment);
    MU_READ_IDS.add(newComment.id);
    chrome.storage.local.set({ [readKey()]: [...MU_READ_IDS] });
    addPin(newComment);
    updateBadge();
    closePopover();
  });
}

// ピンホバー時：コメント詳細をポップオーバーで表示
async function openCommentDetail(comment, pageX, pageY) {
  const seq = ++MU_DETAIL_SEQ;
  MU.selectedId = comment.id;
  Object.values(MU.pinElements).forEach(p => p.classList.remove('mu-sel'));
  MU.pinElements[comment.id]?.classList.add('mu-sel');

  // 未読→既読マーク（ローカル保存）
  if (!MU_READ_IDS.has(comment.id)) {
    MU_READ_IDS.add(comment.id);
    chrome.storage.local.set({ [readKey()]: [...MU_READ_IDS] });
    MU.pinElements[comment.id]?.classList.remove('mu-unread');
  }

  const replies = (await sb_getReplies(comment.id)) || [];
  if (seq !== MU_DETAIL_SEQ) return; // 新しいリクエストに追い越された場合は中断
  const num = MU.comments.findIndex(c => c.id === comment.id) + 1;
  const stLabel = { open: '未対応', fixed: '対応済', verified: '確認完了', rejected: '差し戻し' };
  const stTrans = {
    open:     [{ to: 'fixed',    label: '対応済にする' }],
    fixed:    [{ to: 'verified', label: '確認完了にする' }, { to: 'rejected', label: '差し戻す' }],
    verified: [{ to: 'open',     label: '未対応に戻す'  }, { to: 'rejected', label: '差し戻す' }],
    rejected: [{ to: 'fixed',    label: '再対応済にする' }]
  };
  const transHtml = (stTrans[comment.status] || [])
    .map(t => `<button class="mu-st-btn mu-st-to-${t.to}" data-id="${comment.id}" data-next="${t.to}">${t.label}</button>`)
    .join('');

  const repliesHtml = replies.map(r => `
    <div class="mu-reply-card">
      <div class="mu-meta">
        <span class="mu-author">${escHtml(r.author)}</span>
        ${r.assignee ? `<span class="mu-to">→ @${escHtml(r.assignee)}</span>` : ''}
        <span class="mu-date">${formatDate(r.created_at)}</span>
      </div>
      <div class="mu-text">${escHtml(r.text)}</div>
      ${attachmentHtml(r.image_paths)}
    </div>`).join('');

  showPopover(pageX, pageY, `
    <div class="mu-pop-hdr">
      <div class="mu-hdr-left">
        <span class="mu-pop-ttl">コメント #${num}</span>
        <span class="mu-hdr-st mu-st-${comment.status}">${stLabel[comment.status]}</span>
      </div>
      <button class="mu-pop-x" id="mu-pop-x">✕</button>
    </div>
    <div class="mu-pop-scroll">
      <div class="mu-main-card">
        <div class="mu-meta">
          <span class="mu-author">${escHtml(comment.author)}</span>
          ${comment.assignee ? `<span class="mu-to">→ @${escHtml(comment.assignee)}</span>` : ''}
          <span class="mu-date">${formatDate(comment.created_at)}</span>
        </div>
        <div class="mu-text">${escHtml(comment.text)}</div>
        ${attachmentHtml(comment.image_paths)}
        <div class="mu-acts">
          ${transHtml}
          ${comment.author === MU.userName ? `<button class="mu-del-btn" id="mu-del-btn" data-id="${comment.id}">🗑 削除</button>` : ''}
        </div>
      </div>
      ${repliesHtml ? `<div class="mu-replies">${repliesHtml}</div>` : ''}
      <div class="mu-rform">
        <textarea class="mu-ta" id="mu-reply-text" placeholder="返信を入力…"></textarea>
        <div class="mu-dd" id="mu-reply-dd"></div>
        <div class="mu-prev" id="mu-reply-prev"></div>
        <div id="mu-reply-err" class="mu-err"></div>
        <div class="mu-fa">
          <button class="mu-btn mu-img-btn" id="mu-reply-attach-btn">📎 添付</button>
          <input type="file" id="mu-reply-img" style="display:none">
          <button class="mu-btn mu-img-btn" id="mu-reply-ss-btn">スクショ</button>
          <button class="mu-btn mu-sub" id="mu-reply-submit">返信</button>
        </div>
      </div>
    </div>`);

  document.getElementById('mu-pop-x').addEventListener('click', closePopover);

  document.getElementById('mu-del-btn')?.addEventListener('click', async (e) => {
    if (!confirm('このコメントを削除しますか？（返信も一緒に削除されます）')) return;
    const cid = e.currentTarget.dataset.id;
    await sb_deleteComment(cid);
    MU.comments = MU.comments.filter(c => c.id !== cid);
    MU_CACHE[MU.device] = MU.comments;
    MU.pinElements[cid]?.remove();
    delete MU.pinElements[cid];
    updateBadge();
    closePopover();
  });


  document.querySelectorAll('#mu-popover .mu-st-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const newSt = e.currentTarget.dataset.next;
      const cid   = e.currentTarget.dataset.id;
      await sb_updateStatus(cid, newSt);
      const c = MU.comments.find(c => c.id === cid);
      if (c) {
        c.status = newSt;
        const pin = MU.pinElements[cid];
        if (pin) pin.className = `mu-pin mu-pin-${newSt} mu-sel`;
      }
      updateBadge();
      openCommentDetail({ ...comment, status: newSt }, pageX, pageY);
    });
  });

  let replyImages = [], members = [];
  sb_getMembers().then(m => { members = m || []; });

  setupMention('mu-reply-text', 'mu-reply-dd', () => members, (name) => {
    const ta = document.getElementById('mu-reply-text');
    const at = ta.value.lastIndexOf('@');
    ta.value = ta.value.slice(0, at) + '@' + name + ' ';
    document.getElementById('mu-reply-dd').style.display = 'none';
    ta.focus();
  });

  const replyImgInp = document.getElementById('mu-reply-img');
  document.getElementById('mu-reply-attach-btn').addEventListener('click', () => {
    lockForFilePicker(replyImgInp);
    replyImgInp.click();
  });
  document.getElementById('mu-reply-ss-btn').addEventListener('click', async () => {
    const btn = document.getElementById('mu-reply-ss-btn');
    btn.disabled = true;
    btn.textContent = '撮影中…';
    const err = document.getElementById('mu-reply-err');
    try {
      const ss = await captureScreenshot();
      replyImages.push(ss);
      const previewBlob = await (await fetch(ss.preview)).blob();
      const previewFile = new File([previewBlob], 'screenshot.jpg', { type: 'image/jpeg' });
      addImgThumb('mu-reply-prev', previewFile, () => { const i = replyImages.indexOf(ss); if (i !== -1) replyImages.splice(i, 1); });
      if (err) err.textContent = '';
    } catch (e) {
      if (err) err.textContent = 'スクリーンショットの取得に失敗しました。';
    } finally {
      btn.disabled = false;
      btn.textContent = 'スクショ';
    }
  });
  replyImgInp.addEventListener('change', (e) => {
    MU_FILE_OPEN = false;
    const file = e.target.files[0];
    if (!file) return;
    const err = document.getElementById('mu-reply-err');
    if (file.size > MU_MAX_FILE) {
      if (err) err.textContent = `ファイルが10MBを超えています（${(file.size/1024/1024).toFixed(1)}MB）`;
      e.target.value = '';
      return;
    }
    if (err) err.textContent = '';
    replyImages.push(file);
    addImgThumb('mu-reply-prev', file, () => { const i = replyImages.indexOf(file); if (i !== -1) replyImages.splice(i, 1); });
  });

  document.getElementById('mu-reply-submit').addEventListener('click', async () => {
    const text = document.getElementById('mu-reply-text').value.trim();
    if (!text) return;
    const btn = document.getElementById('mu-reply-submit');
    btn.disabled = true; btn.textContent = '送信中…';

    const result = await sb_addComment({
      session_id: MU.sessionId,
      page_url:   MU.pageUrl,
      breakpoint: MU.device,
      x_percent: comment.x_percent, y_percent: comment.y_percent,
      text, author: MU.userName, assignee: extractMention(text),
      status: 'open', parent_id: comment.id, image_paths: []
    });

    if (!result || !result[0]) {
      btn.disabled = false; btn.textContent = '返信';
      const err = document.getElementById('mu-reply-err');
      if (err) err.textContent = '送信に失敗しました。再度お試しください。';
      return;
    }
    const newReply = result[0];
    if (replyImages.length > 0) {
      try {
        const paths = [];
        for (const item of replyImages) {
          if (item?.type === 'screenshot') {
            const r = await chrome.runtime.sendMessage({ type: 'UPLOAD_SCREENSHOT', tempId: item.tempId, commentId: newReply.id });
            if (!r?.ok) throw new Error(r?.error || 'スクリーンショットのアップロード失敗');
            paths.push(r.url);
          } else {
            paths.push(await sb_uploadImage(item, newReply.id));
          }
        }
        await sb_updateImagePaths(newReply.id, paths);
      } catch (e) {
        console.error('[Mark Upper] 画像アップロード失敗:', e);
        const err = document.getElementById('mu-reply-err');
        if (err) err.textContent = `画像のアップロードに失敗しました: ${e.message}`;
        btn.disabled = false; btn.textContent = '返信';
        return;
      }
    }
    openCommentDetail(comment, pageX, pageY);
  });
}

async function loadComments() {
  if (!MU.sessionId) return;
  const comments = await sb_getComments(MU.sessionId, MU.pageUrl, MU.device);
  MU.comments = comments || [];
  MU_CACHE[MU.device] = MU.comments;
  Object.values(MU.pinElements).forEach(el => el.remove());
  MU.pinElements = {};
  syncOverlaySize();
  MU.comments.forEach(addPin);
  updateBadge();
  if (MU.jumpToId) {
    const target = MU.comments.find(c => c.id === MU.jumpToId);
    MU.jumpToId = null;
    if (target) {
      setTimeout(() => {
        const { pageY } = getPinPagePosition(target);
        window.scrollTo({ top: Math.max(0, pageY - window.innerHeight / 2 + 20), behavior: 'smooth' });
      }, 400);
    }
  }
}

function addPin(comment) {
  const overlay = document.getElementById('mu-overlay');
  if (!overlay) return;

  const num = MU.comments.findIndex(c => c.id === comment.id) + 1;
  const pin = document.createElement('div');
  pin.className = `mu-pin mu-pin-${comment.status}${MU_READ_IDS.has(comment.id) ? '' : ' mu-unread'}`;
  pin.dataset.id = comment.id;

  const _initDoc = getPinPagePosition(comment);
  const { pageX: initX, pageY: initY } = vpToBodyLocal(_initDoc.pageX, _initDoc.pageY);
  pin.style.left = initX + 'px';
  pin.style.top  = initY + 'px';
  pin.innerHTML  = `<span class="mu-pin-shape"><span class="mu-pnum">${num}</span></span>`;

  // ホバーでポップオーバー表示（現在位置を毎回再計算）
  pin.addEventListener('mouseenter', () => {
    if (MU_DRAG) return; // ドラッグ中はポップオーバーを開かない
    clearHoverTimer();
    const _hDoc = getPinPagePosition(comment);
    const { pageX, pageY } = vpToBodyLocal(_hDoc.pageX, _hDoc.pageY);
    openCommentDetail(comment, pageX, pageY);
  });
  pin.addEventListener('mouseleave', startHoverClose);

  // 自分が投稿したコメントのピンだけドラッグ移動できるようにする
  if (comment.author === MU.userName) {
    pin.classList.add('mu-draggable');
    pin.addEventListener('mousedown', (e) => startPinDrag(e, comment, pin));
  }

  overlay.appendChild(pin);
  MU.pinElements[comment.id] = pin;
}

// ---- ピンのドラッグ移動 ----
// マウスダウンで開始、移動中はピンがマウスに追従、マウスアップで確定。
// 確定後はクリック地点の真下の要素から位置情報を作り直してDBへ保存する。
let MU_DRAG = null;

function startPinDrag(e, comment, pin) {
  // 左クリックのみ。自分のコメント以外はそもそもこのリスナーが付かない
  if (e.button !== 0) return;
  e.preventDefault();
  e.stopPropagation();

  // ドラッグ開始時点ではまだ「移動」と確定しない（クリックと区別するため）
  MU_DRAG = {
    comment, pin,
    startX: e.clientX, startY: e.clientY,
    moved: false
  };

  // ドラッグ中はホバーのポップオーバーが邪魔なので閉じておく
  clearHoverTimer();
  closePopover();
  pin.classList.add('mu-dragging');

  window.addEventListener('mousemove', onPinDragMove);
  window.addEventListener('mouseup', onPinDragEnd);
}

function onPinDragMove(e) {
  if (!MU_DRAG) return;
  const dx = e.clientX - MU_DRAG.startX;
  const dy = e.clientY - MU_DRAG.startY;
  // 数px動いて初めて「ドラッグ」とみなす（誤クリックでの移動を防ぐ）
  if (!MU_DRAG.moved && Math.abs(dx) + Math.abs(dy) < 4) return;
  MU_DRAG.moved = true;

  const docX = e.clientX + window.pageXOffset;
  const docY = e.clientY + window.pageYOffset;
  const { pageX, pageY } = vpToBodyLocal(docX, docY);
  MU_DRAG.pin.style.left = pageX + 'px';
  MU_DRAG.pin.style.top  = pageY + 'px';
}

async function onPinDragEnd(e) {
  const drag = MU_DRAG;
  window.removeEventListener('mousemove', onPinDragMove);
  window.removeEventListener('mouseup', onPinDragEnd);
  if (!drag) return;
  drag.pin.classList.remove('mu-dragging');

  // ほとんど動いていなければ移動とみなさない（ホバー表示はそのまま使える）
  if (!drag.moved) { MU_DRAG = null; return; }
  MU_DRAG_GUARD_UNTIL = Date.now() + 250;

  const docX = e.clientX + window.pageXOffset;
  const docY = e.clientY + window.pageYOffset;
  const { pageX, pageY } = vpToBodyLocal(docX, docY);
  const { w, h } = overlayDims();
  const xPct = (pageX / w) * 100;
  const yPct = (pageY / h) * 100;

  // ピンの真下にある要素を取得（オーバーレイは一時的に透過させる）
  const overlay = document.getElementById('mu-overlay');
  if (overlay) overlay.style.pointerEvents = 'none';
  const target = document.elementFromPoint(e.clientX, e.clientY);
  if (overlay) overlay.style.pointerEvents = '';

  // anchor 保存にはドキュメント座標を使う（onOverlayClick と同じルール）
  const elementData = buildElementData(target, docX, docY);

  // ローカルのコメントデータを新座標で更新
  const c = drag.comment;
  c.x_percent = xPct;
  c.y_percent = yPct;
  if (elementData) {
    c.element_selector = elementData.element_selector;
    c.el_x_pct = elementData.el_x_pct;
    c.el_y_pct = elementData.el_y_pct;
  } else {
    c.element_selector = null;
    c.el_x_pct = null;
    c.el_y_pct = null;
  }

  // 確定位置にピンを置き直す
  const _fDoc = getPinPagePosition(c);
  const { pageX: fx, pageY: fy } = vpToBodyLocal(_fDoc.pageX, _fDoc.pageY);
  drag.pin.style.left = fx + 'px';
  drag.pin.style.top  = fy + 'px';

  MU_DRAG = null;

  // DBへ保存
  try {
    await sb_updatePosition(c.id, {
      x_percent: xPct,
      y_percent: yPct,
      element_selector: c.element_selector,
      el_x_pct: c.el_x_pct,
      el_y_pct: c.el_y_pct
    });
  } catch (_) {
    showCursorAlert(fx, fy, '⚠ 位置の保存に失敗しました');
  }
}

function setupMention(textareaId, dropdownId, getMembers, onSelect) {
  const ta = document.getElementById(textareaId);
  if (!ta) return;
  ta.addEventListener('input', () => {
    const val = ta.value;
    const at  = val.lastIndexOf('@');
    const dd  = document.getElementById(dropdownId);
    if (at !== -1) {
      const filtered = getMembers().filter(m => m.name.toLowerCase().includes(val.slice(at + 1).toLowerCase()));
      if (filtered.length) {
        dd.style.display = 'block';
        dd.innerHTML = filtered.map(m => `<div class="mu-mi" data-name="${escHtml(m.name)}">${escHtml(m.name)}</div>`).join('');
        dd.querySelectorAll('.mu-mi').forEach(el => el.addEventListener('click', () => onSelect(el.dataset.name)));
      } else { dd.style.display = 'none'; }
    } else { if (dd) dd.style.display = 'none'; }
  });
}

async function captureScreenshot() {
  // MU の UI（ツールバー・パネル・コメント一覧・幅/%バー・ハンドル・ピン等）を全部隠す。
  // #mu-vp-style（仮想ビューポートの拡大縮小）は site 表示そのものなので残す。
  // ※ visibility:hidden ではなく display:none を使う。MU要素は all:initial を持つものが多く、
  //   all:initial は子要素の visibility を visible に戻すため、親を visibility:hidden にしても
  //   一部の子（PC/Mobileボタン等）が写り込んでしまう。display:none なら子も確実に消える。
  const hideStyle = document.createElement('style');
  hideStyle.id = 'mu-capture-hide';
  hideStyle.textContent = `
    #mu-toolbar, #mu-overlay, #mu-popover, #mu-nav, #mu-panel,
    #mu-sites-modal, #mu-name-panel, #mu-cursor-alert,
    #mu-notify-btn, #mu-update-btn, #mu-lightbox,
    #mu-vp-bar, #mu-vp-handle, #mu-vp-bot-handle, #mu-vp-corner,
    .mu-pin { display: none !important; }`;
  document.documentElement.appendChild(hideStyle);
  await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
  try {
    const crop = siteCropRect();
    const res = await chrome.runtime.sendMessage({ type: 'CAPTURE_SCREENSHOT', crop });
    if (!res?.ok) throw new Error(res?.error || 'キャプチャ失敗');
    return { type: 'screenshot', tempId: res.tempId, preview: res.preview };
  } finally {
    hideStyle.remove();
  }
}

// captureVisibleTab はビューポート全体を撮るため、サイト本体の矩形だけを切り抜く。
// body は vp-sim で transform(scale)・余白付きで表示されるが、getBoundingClientRect は
// transform 適用後の見た目の矩形を返すので、これをビューポートと交差させれば
// 上の黒帯（ツールバー余白）・左右のレターボックス・1px枠線をすべて除外できる。
function siteCropRect() {
  const r  = document.body.getBoundingClientRect();
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const x  = Math.max(0, r.left);
  const y  = Math.max(0, r.top);
  const right  = Math.min(vw, r.left + r.width);
  const bottom = Math.min(vh, r.top + r.height);
  return { x, y, w: Math.max(0, right - x), h: Math.max(0, bottom - y), vw };
}

function addImgThumb(previewId, file, onRemove) {
  const prev = document.getElementById(previewId);
  if (!prev) return;
  const div = document.createElement('div');
  div.className = 'mu-thumb';
  div.title = file.name;
  if (file.type.startsWith('image/')) {
    const url = URL.createObjectURL(file);
    MU_OBJECT_URLS.push(url);
    div.innerHTML = `<img src="${url}">`;
  } else {
    const ext = (file.name.split('.').pop() || 'FILE').toUpperCase().slice(0, 6);
    const short = file.name.length > 16 ? file.name.slice(0, 13) + '…' : file.name;
    div.innerHTML = `<div class="mu-file-thumb"><span class="mu-file-ext">${escHtml(ext)}</span><span class="mu-file-name">${escHtml(short)}</span></div>`;
  }
  if (onRemove) {
    const rm = document.createElement('button');
    rm.className = 'mu-thumb-rm';
    rm.textContent = '✕';
    rm.addEventListener('click', (e) => { e.stopPropagation(); onRemove(); div.remove(); });
    div.appendChild(rm);
  }
  prev.appendChild(div);
}

async function setDevice(device) {
  MU.device = device;
  MU.vpCustomW     = null;
  MU.vpCustomScale = null;
  MU.vpCustomH     = null;
  chrome.storage.local.set({ mu_device: device });
  document.getElementById('mu-dev-pc')?.classList.toggle('mu-seg-on', device === 'pc');
  document.getElementById('mu-dev-mobile')?.classList.toggle('mu-seg-on', device === 'mobile');
  applyViewportSim();
  updateToolbarLayout();
  if (MU.active) {
    if (MU_CACHE[device]) {
      MU.comments = MU_CACHE[device];
      Object.values(MU.pinElements).forEach(el => el.remove());
      MU.pinElements = {};
      syncOverlaySize();
      MU.comments.forEach(addPin);
      updateBadge();
    } else {
      await loadComments();
    }
    closePopover();
  }
}

function updateBadge() {
  if (MU.panelOpen) updatePanel();
}

function extractMention(text) {
  const m = text.match(/@(\S+)/);
  return m ? m[1] : null;
}

function showUpdatePill(version, downloadUrl) {
  document.getElementById('mu-update-btn')?.remove();
  const btn = document.createElement('button');
  btn.id = 'mu-update-btn';
  btn.className = 'mu-pill mu-update-pill';
  btn.textContent = `↑ v${version} に更新`;
  btn.title = '新しいバージョンがあります。クリックしてダウンロード';
  btn.addEventListener('click', () => {
    if (downloadUrl) window.open(downloadUrl, '_blank');
  });
  document.getElementById('mu-toolbar')?.querySelector('.mu-right')?.prepend(btn);
}

function applyTheme() {
  if (MU.theme === 'light') {
    document.documentElement.classList.add('mu-light');
  } else {
    document.documentElement.classList.remove('mu-light');
  }
}

function toggleTheme() {
  MU.theme = MU.theme === 'dark' ? 'light' : 'dark';
  chrome.storage.local.set({ mu_theme: MU.theme });
  applyTheme();
  const btn = document.getElementById('mu-theme-btn');
  if (btn) {
    btn.textContent = MU.theme === 'dark' ? '☀' : '🌙';
    btn.title = MU.theme === 'dark' ? 'ライトモードへ' : 'ダークモードへ';
  }
}

async function clearSiteComments() {
  if (!MU.sessionId) return;
  const all = await sb_getAllSessionComments(MU.sessionId);
  const total = all?.length || 0;
  if (!total) return;
  if (!window.confirm(`このサイトのコメントを全て削除しますか？\n（${total}件・全ページ対象）`)) return;
  await sb_deleteSessionComments(MU.sessionId);
  Object.values(MU.pinElements).forEach(el => el.remove());
  MU.pinElements = {};
  MU.comments = [];
  MU_CACHE.pc = null;
  MU_CACHE.mobile = null;
  closePopover();
  if (MU.panelOpen) {
    await updatePanel();
  } else {
    updateBadge();
  }
}

function formatDate(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const Y = d.getFullYear();
  const M = d.getMonth() + 1;
  const D = d.getDate();
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  return `${Y}/${M}/${D} ${h}:${m}`;
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// 添付ファイル一覧HTML（すべてファイルチップでタップ→新タブ）
function attachmentHtml(paths) {
  if (!paths?.length) return '';
  const items = paths.map(p => {
    const name = decodeURIComponent(p.split('/').pop() || 'file');
    const isImg = /\.(jpg|jpeg|png|gif|webp|svg|bmp)(\?|$)/i.test(p);
    const ext   = (name.split('.').pop() || 'FILE').toUpperCase().slice(0, 6);
    const label = name.length > 22 ? name.slice(0, 10) + '…' + name.slice(-8) : name;
    const icon  = isImg ? '🖼' : '📎';
    return `<a href="${escHtml(p)}" target="_blank" rel="noopener" class="mu-file-link" title="${escHtml(name)}"><div class="mu-file-thumb"><span class="mu-file-ext">${icon}</span><span class="mu-file-name">${escHtml(label)}</span></div></a>`;
  }).join('');
  return `<div class="mu-imgs">${items}</div>`;
}
