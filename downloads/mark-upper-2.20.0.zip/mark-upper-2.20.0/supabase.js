const SUPABASE_URL = 'https://hiccejzetnmmvyopyykw.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhpY2NlanpldG5tbXZ5b3B5eWt3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg4MjkwMTYsImV4cCI6MjA5NDQwNTAxNn0.Oo_KrFflZhhWOlaN_hT9XZpBjhDFAgccK82CyrgC3qU';

const SB_HEADERS = {
  'apikey': SUPABASE_KEY,
  'Authorization': `Bearer ${SUPABASE_KEY}`,
  'Content-Type': 'application/json'
};

// CSP回避のためbackground service worker経由でfetch
function sb_fetch(url, options = {}) {
  return new Promise((resolve) => {
    if (!chrome.runtime?.id) { resolve(null); return; }
    try {
      chrome.runtime.sendMessage(
        { type: 'SUPABASE_FETCH', url, method: options.method || 'GET', headers: options.headers, body: options.body },
        (res) => resolve(chrome.runtime.lastError ? null : (res || null))
      );
    } catch (_) { resolve(null); }
  });
}

async function sb_query(path, method = 'GET', body = null) {
  try {
    const headers = {
      ...SB_HEADERS,
      ...(method === 'POST' ? { 'Prefer': 'return=representation' } : {})
    };
    const res = await sb_fetch(`${SUPABASE_URL}/rest/v1${path}`, {
      method, headers,
      body: body ? JSON.stringify(body) : undefined
    });
    if (!res) return null;
    if (res.status === 204) return null;
    if (!res.ok) throw new Error(JSON.stringify(res.data));
    return res.data;
  } catch (e) {
    console.warn('[Mark Upper]', e.message);
    return null;
  }
}

// ── セッション ─────────────────────────────────────────────
async function sb_getOrCreateSession(domain) {
  const existing = await sb_query(
    `/mu_sessions?domain=eq.${encodeURIComponent(domain)}&order=created_at.desc&limit=1`
  );
  if (existing?.length) return existing[0];
  const created = await sb_query('/mu_sessions', 'POST', { domain });
  return created?.[0] || null;
}

async function sb_getSessionById(id) {
  const data = await sb_query(`/mu_sessions?id=eq.${encodeURIComponent(id)}`);
  return data?.[0] || null;
}

// ── メンバー（@メンション補完用）──────────────────────────
async function sb_getMembers() {
  return sb_query('/mu_members?select=name&order=name.asc');
}

async function sb_addMember(name) {
  try { await sb_query('/mu_members', 'POST', { name }); } catch (_) {}
}

// ── コメント ───────────────────────────────────────────────
async function sb_getAllSessionComments(sessionId) {
  const sid = encodeURIComponent(sessionId);
  return sb_query(
    `/mu_comments?session_id=eq.${sid}&parent_id=is.null&select=*&order=page_url.asc,created_at.asc`
  );
}

async function sb_getComments(sessionId, pageUrl, breakpoint) {
  const sid = encodeURIComponent(sessionId);
  const url = encodeURIComponent(pageUrl);
  const bp  = encodeURIComponent(breakpoint);
  return sb_query(
    `/mu_comments?session_id=eq.${sid}&page_url=eq.${url}&breakpoint=eq.${bp}&parent_id=is.null&select=*&order=created_at.asc`
  );
}

async function sb_getReplies(parentId) {
  return sb_query(`/mu_comments?parent_id=eq.${encodeURIComponent(parentId)}&select=*&order=created_at.asc`);
}

async function sb_addComment(data) {
  return sb_query('/mu_comments', 'POST', data);
}

async function sb_deleteComment(id) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_deleteSessionComments(sessionId) {
  const sid = encodeURIComponent(sessionId);
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?session_id=eq.${sid}`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_deletePageComments(sessionId, pageUrl) {
  const sid = encodeURIComponent(sessionId);
  const url = encodeURIComponent(pageUrl);
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?session_id=eq.${sid}&page_url=eq.${url}`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_deleteAllComments(sessionId, pageUrl) {
  const sid = encodeURIComponent(sessionId);
  const url = encodeURIComponent(pageUrl);
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?session_id=eq.${sid}&page_url=eq.${url}&parent_id=is.null`, {
    method: 'DELETE', headers: SB_HEADERS
  });
}

async function sb_updateStatus(id, status) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH', headers: SB_HEADERS, body: JSON.stringify({ status })
  });
}

async function sb_updatePosition(id, pos) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH', headers: SB_HEADERS, body: JSON.stringify(pos)
  });
}

async function sb_updateImagePaths(id, paths) {
  await sb_fetch(`${SUPABASE_URL}/rest/v1/mu_comments?id=eq.${encodeURIComponent(id)}`, {
    method: 'PATCH', headers: SB_HEADERS, body: JSON.stringify({ image_paths: paths })
  });
}

async function sb_getMySites(userName) {
  if (!userName) return [];
  const comments = await sb_query(
    `/mu_comments?author=eq.${encodeURIComponent(userName)}&parent_id=is.null&select=session_id,status`
  );
  if (!comments?.length) return [];
  const counts = {};
  comments.forEach(c => {
    if (!counts[c.session_id]) counts[c.session_id] = { open: 0, fixed: 0, verified: 0, rejected: 0, total: 0 };
    counts[c.session_id][c.status] = (counts[c.session_id][c.status] || 0) + 1;
    counts[c.session_id].total++;
  });
  const ids = Object.keys(counts);
  const sessions = await sb_query(`/mu_sessions?id=in.(${ids.join(',')})&select=id,domain`);
  return (sessions || [])
    .map(s => ({ domain: s.domain, id: s.id, status: counts[s.id] || { open: 0, fixed: 0, verified: 0, rejected: 0, total: 0 } }))
    .sort((a, b) => b.status.total - a.status.total);
}

async function sb_uploadImage(file, commentId) {
  const ext  = file.name.split('.').pop() || 'png';
  const path = `${commentId}/${Date.now()}.${ext}`;
  const buf  = await file.arrayBuffer();
  const res  = await sb_fetch(`${SUPABASE_URL}/storage/v1/object/comment-images/${path}`, {
    method: 'POST',
    headers: { 'apikey': SUPABASE_KEY, 'Authorization': `Bearer ${SUPABASE_KEY}`, 'Content-Type': file.type },
    body: buf
  });
  if (!res || !res.ok) throw new Error('ファイルのアップロードに失敗しました');
  return `${SUPABASE_URL}/storage/v1/object/public/comment-images/${path}`;
}
